# CLD2 alpha51.1 — aggregate artifact benchmark report

This report is generated from `bench_real_result.json` files.

## Summary

| Scenario | Class | Best CLD2 | Raw baseline | Best conventional baseline | CLD2/raw | CLD2/conventional |
|---|---|---:|---:|---:|---:|---:|
| model_pack_localized_random | high-reuse-win | 2.00 MiB via `fixed` | 64.00 MiB | file_level_tar_zstd_bytes: 64.00 MiB | 0.031251 | 0.031250 |

## Interpretation

### model_pack_localized_random

- Classification: **high-reuse-win**
- Reason: CLD2 is clearly below the best conventional compressed baseline.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 2.00 MiB
- Raw baseline: 64.00 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 64.00 MiB

## Claim boundary

Alpha51.1 is an artifact-pair benchmark. It does not prove that CLD2 always wins. Results should be interpreted per artifact and per update pattern.
