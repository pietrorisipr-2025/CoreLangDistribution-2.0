﻿# CLD2 benchmark report — model_pack_localized_random / large-file-balanced

Version: `2.0.0-alpha50.2`

## Core result

| Method | Download pack bytes | Raw chunk bytes | Chunk reuse | Reused | Added | Removed | Pack v1 | Pack v2 | Total pack | Saved vs file-level raw | Saved vs tar.zst update |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fixed | 2097241 | 2097241 | 95.3846% | 62 | 3 | 3 | 1.9638 s | 1.8795 s | 3.8433 s | 96.8749% | 96.8750% |
| fastcdc | 7082651 | 7082651 | 88.8889% | 40 | 5 | 5 | 3.7872 s | 3.8292 s | 7.6164 s | 89.4460% | 89.4463% |

fastcdc packing slowdown vs fixed: **1.98×**.

## Baseline

- V1 logical bytes: 67108938
- V2 logical bytes: 67108953
- File-level raw update bytes: 67108953
- File-level tar.gz update bytes: 67129732
- File-level tar.zst update bytes: 67110703
- Full tar.gz v2 bytes: 67129774
- Full tar.zst v2 bytes: 67110747

## Scenario metadata

```json
{
  "added_file_count": 0,
  "common_file_count": 2,
  "new_file_count": 2,
  "note": "Alpha18 metadata records size-level changes. Exact byte-level delta requires an explicit scenario generator or external diff.",
  "old_file_count": 2,
  "removed_file_count": 0,
  "size_changed_file_count": 1,
  "size_changed_sample": [
    {
      "new_size": 89,
      "old_size": 74,
      "path": "model.json",
      "size_delta": 15
    }
  ]
}
```

## Profile

```json
{
  "change_ratio": 1.0,
  "chunk_avg": "512KiB",
  "chunk_max": "2MiB",
  "chunk_min": "128KiB",
  "fastcdc_stride": 8,
  "file_size": "128MiB",
  "files": 1,
  "fixed_size": "1MiB"
}
```

## Interpretation guardrail

This benchmark compares update strategies. A large-file insertion/boundary-shift scenario is favorable to CDC and should not be marketed as universal compression. CDC is expected to help when releases share many unchanged byte ranges; it is not expected to create savings on encrypted, random, transcoded or completely rewritten data.

