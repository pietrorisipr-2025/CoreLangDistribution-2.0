# CLD2 distribution savings report — model_pack_localized_random

## Executive summary

This report compares file-level/full redistribution against CLD2 chunk-level updates. It is a transparent byte * downloads * egress-price estimate, not a production SLA.

- Downloads/users modelled: 1000
- Egress price model: 0.09 USD/GiB
- Cost note: Estimated egress only: bytes * downloads * cost_per_GiB. It excludes storage, requests, cache hit rates, taxes, and CDN tiering.

## Update-size comparison

| Method | Update bytes | Chunk reuse | Saved vs raw file-level | Saved vs tar.zst update | Estimated egress cost |
|---|---:|---:|---:|---:|---:|
| CLD2 fixed | 2097241 | 95.3846% | 96.8749% | 96.8750% | 0.175789 USD |
| CLD2 fastcdc | 7082651 | 88.8889% | 89.4460% | 89.4463% | 0.593661 USD |

## Baselines

| Baseline | Bytes | Estimated egress cost | Source |
|---|---:|---:|---|
| Full logical v2 | 67108953 | 5.625 USD | measured |
| Full tar.gz v2 | 67129774 | 5.627 USD | measured |
| Full tar.zst v2 | 67110747 | 5.625 USD | measured |
| Changed files raw | 67108953 | 5.625 USD | measured |
| Changed files tar.gz | 67129732 | 5.627 USD | measured |
| Changed files tar.zst | 67110703 | 5.625 USD | measured |

## Savings projection

| Method | Saved vs changed-files raw | Saved vs changed-files tar.zst | Saved vs full tar.zst |
|---|---:|---:|---:|
| CLD2 fixed | 5.449 USD (96.8749%) | 5.449 USD (96.8750%) | 5.449 USD (96.8750%) |
| CLD2 fastcdc | 5.031 USD (89.4460%) | 5.031 USD (89.4463%) | 5.031 USD (89.4463%) |

## Technical details

```json
{
  "comparison": {
    "fixed_download_bytes": 2097241,
    "optimized_download_bytes": 7082651,
    "optimized_method": "fastcdc",
    "optimized_saved_ratio_vs_fixed": 0.0,
    "optimized_saved_vs_fixed_bytes": 0
  },
  "profile": "large-file-balanced",
  "profiles": null,
  "scenario": "model_pack_localized_random"
}
```

## Interpretation guardrail

CLD2 is expected to help when release A and release B share many chunks. It is not expected to create savings on encrypted/random/completely rewritten data. Real CDN bills also depend on cache hit ratio, regions, request pricing and negotiated tiers.
