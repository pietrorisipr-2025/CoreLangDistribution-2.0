# CLD2 distribution savings report — badfit_entropy_rewrite

## Executive summary

This report compares file-level/full redistribution against CLD2 chunk-level updates. It is a transparent byte * downloads * egress-price estimate, not a production SLA.

- Downloads/users modelled: 1000
- Egress price model: 0.09 USD/GiB
- Cost note: Estimated egress only: bytes * downloads * cost_per_GiB. It excludes storage, requests, cache hit rates, taxes, and CDN tiering.

## Update-size comparison

| Method | Update bytes | Chunk reuse | Saved vs raw file-level | Saved vs tar.zst update | Estimated egress cost |
|---|---:|---:|---:|---:|---:|
| CLD2 fixed | 67108913 | 0.0000% | 0.0000% | 0.0048% | 5.625 USD |
| CLD2 fastcdc | 67108913 | 0.0000% | 0.0000% | 0.0048% | 5.625 USD |

## Baselines

| Baseline | Bytes | Estimated egress cost | Source |
|---|---:|---:|---|
| Full logical v2 | 67108913 | 5.625 USD | measured |
| Full tar.gz v2 | 67129843 | 5.627 USD | measured |
| Full tar.zst v2 | 67110800 | 5.625 USD | measured |
| Changed files raw | 67108913 | 5.625 USD | measured |
| Changed files tar.gz | 67129789 | 5.627 USD | measured |
| Changed files tar.zst | 67112140 | 5.625 USD | measured |

## Savings projection

| Method | Saved vs changed-files raw | Saved vs changed-files tar.zst | Saved vs full tar.zst |
|---|---:|---:|---:|
| CLD2 fixed | 0 USD (0.0000%) | 0.000271 USD (0.0048%) | 0.000158 USD (0.0028%) |
| CLD2 fastcdc | 0 USD (0.0000%) | 0.000271 USD (0.0048%) | 0.000158 USD (0.0028%) |

## Technical details

```json
{
  "comparison": {
    "fixed_download_bytes": 67108913,
    "optimized_download_bytes": 67108913,
    "optimized_method": "fastcdc",
    "optimized_saved_ratio_vs_fixed": 0.0,
    "optimized_saved_vs_fixed_bytes": 0
  },
  "profile": "large-file-balanced",
  "profiles": null,
  "scenario": "badfit_entropy_rewrite"
}
```

## Interpretation guardrail

CLD2 is expected to help when release A and release B share many chunks. It is not expected to create savings on encrypted/random/completely rewritten data. Real CDN bills also depend on cache hit ratio, regions, request pricing and negotiated tiers.
