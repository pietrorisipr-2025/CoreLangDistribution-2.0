﻿# CLD2 benchmark report — badfit_entropy_rewrite / large-file-balanced

Version: `2.0.0-alpha50.2`

## Core result

| Method | Download pack bytes | Raw chunk bytes | Chunk reuse | Reused | Added | Removed | Pack v1 | Pack v2 | Total pack | Saved vs file-level raw | Saved vs tar.zst update |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fixed | 67108913 | 67108913 | 0.0000% | 0 | 65 | 65 | 1.8797 s | 5.201 s | 7.0807 s | 0.0000% | 0.0048% |
| fastcdc | 67108913 | 67108913 | 0.0000% | 0 | 38 | 44 | 3.8363 s | 3.5345 s | 7.3708 s | 0.0000% | 0.0048% |

fastcdc packing slowdown vs fixed: **1.04×**.

## Baseline

- V1 logical bytes: 67108913
- V2 logical bytes: 67108913
- File-level raw update bytes: 67108913
- File-level tar.gz update bytes: 67129789
- File-level tar.zst update bytes: 67112140
- Full tar.gz v2 bytes: 67129843
- Full tar.zst v2 bytes: 67110800

## Scenario metadata

```json
{
  "added_file_count": 0,
  "common_file_count": 2,
  "new_file_count": 2,
  "note": "Alpha18 metadata records size-level changes. Exact byte-level delta requires an explicit scenario generator or external diff.",
  "old_file_count": 2,
  "removed_file_count": 0,
  "size_changed_file_count": 0,
  "size_changed_sample": []
}
```

## Profile

```json
{
  "change_ratio": 1.0,
  "chunk_avg": "512KiB",
  "chunk_max": "2MiB",
  "chunk_min": "128KiB",
  "fastcdc_stride": 8,
  "file_size": "128MiB",
  "files": 1,
  "fixed_size": "1MiB"
}
```

## Interpretation guardrail

This benchmark compares update strategies. A large-file insertion/boundary-shift scenario is favorable to CDC and should not be marketed as universal compression. CDC is expected to help when releases share many unchanged byte ranges; it is not expected to create savings on encrypted, random, transcoded or completely rewritten data.

