# CLD2 alpha51.1 — aggregate artifact benchmark report

This report is generated from `bench_real_result.json` files.

## Summary

| Scenario | Class | Best CLD2 | Raw baseline | Best conventional baseline | CLD2/raw | CLD2/conventional |
|---|---|---:|---:|---:|---:|---:|
| badfit_entropy_rewrite | bad-fit | 64.00 MiB via `fixed` | 64.00 MiB | full_tar_zstd_v2_bytes: 64.00 MiB | 1.000000 | 0.999972 |

## Interpretation

### badfit_entropy_rewrite

- Classification: **bad-fit**
- Reason: CLD2 transfers nearly the full artifact; little useful reuse.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 64.00 MiB
- Raw baseline: 64.00 MiB
- Best conventional baseline: `full_tar_zstd_v2_bytes` = 64.00 MiB

## Claim boundary

Alpha51.1 is an artifact-pair benchmark. It does not prove that CLD2 always wins. Results should be interpreted per artifact and per update pattern.
