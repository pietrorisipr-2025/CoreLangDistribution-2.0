# CLD2 alpha51.2.1 — final clean review
Created: 2026-06-04T13:45:04Z
## Purpose
This package is a cleaned lightweight review bundle for the alpha51.1/51.2/51.2.1 synthetic real-artifact benchmark. It excludes previous nested review-upload folders and large generated artifacts.
## Metadata status
- Code baseline: `2.0.0-alpha50.2`
- Benchmark milestone: `alpha51.2.1`
- Legacy result-version issue corrected in aggregate CSV/JSON/report data.
- No benchmark was rerun for the final polish; this is metadata/report cleanup only.

## Aggregate benchmark summary
| Scenario | Class | Best CLD2 bytes | Best conventional bytes | CLD2/conventional | CLD2/raw |
|---|---:|---:|---:|---:|---:|
| badfit_entropy_rewrite | bad-fit | 67108913 | 67110800 | 0.9999718823199842 | 1.0 |
| domain_pack_mixed_high_reuse | near-parity | 3322887 | 3338482 | 0.9953287152663995 | 0.3728156222126232 |
| many_small_mixed_update | near-parity | 8954732 | 8969921 | 0.9983066740498606 | 0.8836677522964207 |
| model_pack_localized_random | high-reuse-win | 2097241 | 67110703 | 0.031250469839363776 | 0.03125128475778783 |

## Interpretation
- `model_pack_localized_random`: high-reuse win; CLD2 is far below the best conventional compressed baseline.
- `domain_pack_mixed_high_reuse` and `many_small_mixed_update`: near-parity against the best compressed changed-file baseline, while still much better than raw transfer in the domain-pack case.
- `badfit_entropy_rewrite`: bad-fit/near full transfer; CLD2 should not be marketed as winning this case.

## Claim boundary
CLD2 is useful as a warm-update artifact planner when there is meaningful reuse inside or across artifacts. It is not a generic compressor and it should not be claimed to beat every baseline on every workload.
