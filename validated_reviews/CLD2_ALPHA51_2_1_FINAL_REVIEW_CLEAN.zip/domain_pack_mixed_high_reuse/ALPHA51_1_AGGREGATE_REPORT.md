# CLD2 alpha51.1 — aggregate artifact benchmark report

This report is generated from `bench_real_result.json` files.

## Summary

| Scenario | Class | Best CLD2 | Raw baseline | Best conventional baseline | CLD2/raw | CLD2/conventional |
|---|---|---:|---:|---:|---:|---:|
| domain_pack_mixed_high_reuse | near-parity | 3.17 MiB via `cdc` | 8.50 MiB | file_level_tar_zstd_bytes: 3.18 MiB | 0.372816 | 0.995329 |

## Interpretation

### domain_pack_mixed_high_reuse

- Classification: **near-parity**
- Reason: CLD2 is close to the best compressed conventional baseline.
- Best CLD2 method: `cdc`
- Best CLD2 bytes: 3.17 MiB
- Raw baseline: 8.50 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 3.18 MiB

## Claim boundary

Alpha51.1 is an artifact-pair benchmark. It does not prove that CLD2 always wins. Results should be interpreted per artifact and per update pattern.
