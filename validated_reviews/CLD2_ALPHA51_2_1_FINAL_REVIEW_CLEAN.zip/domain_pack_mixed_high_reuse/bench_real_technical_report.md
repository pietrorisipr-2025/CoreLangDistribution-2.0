﻿# CLD2 benchmark report — domain_pack_mixed_high_reuse / medium

Version: `2.0.0-alpha50.2`

## Core result

| Method | Download pack bytes | Raw chunk bytes | Chunk reuse | Reused | Added | Removed | Pack v1 | Pack v2 | Total pack | Saved vs file-level raw | Saved vs tar.zst update |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fixed | 3322889 | 8912950 | 87.7805% | 352 | 49 | 33 | 1.8408 s | 2.1389 s | 3.9797 s | 62.7184% | 0.4671% |
| cdc | 3322887 | 8912950 | 87.5847% | 388 | 55 | 33 | 10.1816 s | 10.3585 s | 20.5401 s | 62.7184% | 0.4671% |

cdc packing slowdown vs fixed: **5.16×**.

## Baseline

- V1 logical bytes: 67108677
- V2 logical bytes: 70429174
- File-level raw update bytes: 8912950
- File-level tar.gz update bytes: 3363324
- File-level tar.zst update bytes: 3338482
- Full tar.gz v2 bytes: 53836700
- Full tar.zst v2 bytes: 53986366

## Scenario metadata

```json
{
  "added_file_count": 16,
  "common_file_count": 385,
  "new_file_count": 401,
  "note": "Alpha18 metadata records size-level changes. Exact byte-level delta requires an explicit scenario generator or external diff.",
  "old_file_count": 385,
  "removed_file_count": 0,
  "size_changed_file_count": 33,
  "size_changed_sample": [
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_00/entry_00000.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_00/entry_00096.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_00/entry_00192.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_00/entry_00288.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_04/entry_00036.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_04/entry_00132.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_04/entry_00228.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_04/entry_00324.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_08/entry_00072.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_08/entry_00168.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_08/entry_00264.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_08/entry_00360.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_12/entry_00012.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_12/entry_00108.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_12/entry_00204.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_12/entry_00300.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_16/entry_00048.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_16/entry_00144.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_16/entry_00240.bin",
      "size_delta": 16384
    },
    {
      "new_size": 191146,
      "old_size": 174762,
      "path": "domain_16/entry_00336.bin",
      "size_delta": 16384
    }
  ]
}
```

## Profile

```json
{
  "change_ratio": null,
  "chunk_avg": "256KiB",
  "chunk_max": "1MiB",
  "chunk_min": "64KiB",
  "file_size": "1MiB",
  "files": 32,
  "fixed_size": "256KiB"
}
```

## Interpretation guardrail

This benchmark compares update strategies. A large-file insertion/boundary-shift scenario is favorable to CDC and should not be marketed as universal compression. CDC is expected to help when releases share many unchanged byte ranges; it is not expected to create savings on encrypted, random, transcoded or completely rewritten data.

