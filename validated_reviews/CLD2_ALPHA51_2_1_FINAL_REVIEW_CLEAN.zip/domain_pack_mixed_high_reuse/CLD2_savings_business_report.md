# CLD2 distribution savings report — domain_pack_mixed_high_reuse

## Executive summary

This report compares file-level/full redistribution against CLD2 chunk-level updates. It is a transparent byte * downloads * egress-price estimate, not a production SLA.

- Downloads/users modelled: 1000
- Egress price model: 0.09 USD/GiB
- Cost note: Estimated egress only: bytes * downloads * cost_per_GiB. It excludes storage, requests, cache hit rates, taxes, and CDN tiering.

## Update-size comparison

| Method | Update bytes | Chunk reuse | Saved vs raw file-level | Saved vs tar.zst update | Estimated egress cost |
|---|---:|---:|---:|---:|---:|
| CLD2 fixed | 3322889 | 87.7805% | 62.7184% | 0.4671% | 0.278521 USD |
| CLD2 cdc | 3322887 | 87.5847% | 62.7184% | 0.4671% | 0.278521 USD |

## Baselines

| Baseline | Bytes | Estimated egress cost | Source |
|---|---:|---:|---|
| Full logical v2 | 70429174 | 5.903 USD | measured |
| Full tar.gz v2 | 53836700 | 4.513 USD | measured |
| Full tar.zst v2 | 53986366 | 4.525 USD | measured |
| Changed files raw | 8912950 | 0.747075 USD | measured |
| Changed files tar.gz | 3363324 | 0.281911 USD | measured |
| Changed files tar.zst | 3338482 | 0.279828 USD | measured |

## Savings projection

| Method | Saved vs changed-files raw | Saved vs changed-files tar.zst | Saved vs full tar.zst |
|---|---:|---:|---:|
| CLD2 fixed | 0.468554 USD (62.7184%) | 0.001307 USD (0.4671%) | 4.247 USD (93.8449%) |
| CLD2 cdc | 0.468554 USD (62.7184%) | 0.001307 USD (0.4671%) | 4.247 USD (93.8450%) |

## Technical details

```json
{
  "comparison": {
    "fixed_download_bytes": 3322889,
    "optimized_download_bytes": 3322887,
    "optimized_method": "cdc",
    "optimized_saved_ratio_vs_fixed": 1e-06,
    "optimized_saved_vs_fixed_bytes": 2
  },
  "profile": "medium",
  "profiles": null,
  "scenario": "domain_pack_mixed_high_reuse"
}
```

## Interpretation guardrail

CLD2 is expected to help when release A and release B share many chunks. It is not expected to create savings on encrypted/random/completely rewritten data. Real CDN bills also depend on cache hit ratio, regions, request pricing and negotiated tiers.
