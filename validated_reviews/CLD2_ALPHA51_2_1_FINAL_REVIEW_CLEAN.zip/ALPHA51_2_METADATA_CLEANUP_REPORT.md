# CLD2 alpha51.2 â€” metadata cleanup report

## Summary

- Code baseline version: `2.0.0-alpha50.2`
- Benchmark harness milestone: `alpha51.2`
- Heavy benchmark rerun: no
- Core CLD2 logic changed: no
- Files changed: 68

## Changed files

| File | Replacements/changes | Kind |
|---|---:|---|
| `_review_upload/alpha51_1_aggregate_summary.csv` | 4 | text |
| `_review_upload/alpha51_1_aggregate_summary.json` | 9 | json |
| `_review_upload/badfit_entropy_rewrite/alpha51_1_aggregate_summary.csv` | 1 | text |
| `_review_upload/badfit_entropy_rewrite/alpha51_1_aggregate_summary.json` | 3 | json |
| `_review_upload/badfit_entropy_rewrite/bench_real_result.json` | 2 | json |
| `_review_upload/badfit_entropy_rewrite/bench_real_technical_report.md` | 1 | text |
| `_review_upload/badfit_entropy_rewrite/repo_v1_fastcdc.cldrepo/release.json` | 3 | json |
| `_review_upload/badfit_entropy_rewrite/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/badfit_entropy_rewrite/repo_v2_fastcdc.cldrepo/release.json` | 3 | json |
| `_review_upload/badfit_entropy_rewrite/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/domain_pack_mixed_high_reuse/alpha51_1_aggregate_summary.csv` | 1 | text |
| `_review_upload/domain_pack_mixed_high_reuse/alpha51_1_aggregate_summary.json` | 3 | json |
| `_review_upload/domain_pack_mixed_high_reuse/bench_real_result.json` | 2 | json |
| `_review_upload/domain_pack_mixed_high_reuse/bench_real_technical_report.md` | 1 | text |
| `_review_upload/domain_pack_mixed_high_reuse/repo_v1_cdc.cldrepo/release.json` | 3 | json |
| `_review_upload/domain_pack_mixed_high_reuse/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/domain_pack_mixed_high_reuse/repo_v2_cdc.cldrepo/release.json` | 3 | json |
| `_review_upload/domain_pack_mixed_high_reuse/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/many_small_mixed_update/alpha51_1_aggregate_summary.csv` | 1 | text |
| `_review_upload/many_small_mixed_update/alpha51_1_aggregate_summary.json` | 3 | json |
| `_review_upload/many_small_mixed_update/bench_real_result.json` | 2 | json |
| `_review_upload/many_small_mixed_update/bench_real_technical_report.md` | 1 | text |
| `_review_upload/many_small_mixed_update/repo_v1_cdc.cldrepo/release.json` | 3 | json |
| `_review_upload/many_small_mixed_update/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/many_small_mixed_update/repo_v2_cdc.cldrepo/release.json` | 3 | json |
| `_review_upload/many_small_mixed_update/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/model_pack_localized_random/alpha51_1_aggregate_summary.csv` | 1 | text |
| `_review_upload/model_pack_localized_random/alpha51_1_aggregate_summary.json` | 3 | json |
| `_review_upload/model_pack_localized_random/bench_real_result.json` | 2 | json |
| `_review_upload/model_pack_localized_random/bench_real_technical_report.md` | 1 | text |
| `_review_upload/model_pack_localized_random/repo_v1_fastcdc.cldrepo/release.json` | 3 | json |
| `_review_upload/model_pack_localized_random/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `_review_upload/model_pack_localized_random/repo_v2_fastcdc.cldrepo/release.json` | 3 | json |
| `_review_upload/model_pack_localized_random/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `alpha51_1_aggregate_summary.csv` | 4 | text |
| `alpha51_1_aggregate_summary.json` | 9 | json |
| `badfit_entropy_rewrite/alpha51_1_aggregate_summary.csv` | 1 | text |
| `badfit_entropy_rewrite/alpha51_1_aggregate_summary.json` | 3 | json |
| `badfit_entropy_rewrite/bench_real_result.json` | 2 | json |
| `badfit_entropy_rewrite/bench_real_technical_report.md` | 1 | text |
| `badfit_entropy_rewrite/repo_v1_fastcdc.cldrepo/release.json` | 3 | json |
| `badfit_entropy_rewrite/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `badfit_entropy_rewrite/repo_v2_fastcdc.cldrepo/release.json` | 3 | json |
| `badfit_entropy_rewrite/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `domain_pack_mixed_high_reuse/alpha51_1_aggregate_summary.csv` | 1 | text |
| `domain_pack_mixed_high_reuse/alpha51_1_aggregate_summary.json` | 3 | json |
| `domain_pack_mixed_high_reuse/bench_real_result.json` | 2 | json |
| `domain_pack_mixed_high_reuse/bench_real_technical_report.md` | 1 | text |
| `domain_pack_mixed_high_reuse/repo_v1_cdc.cldrepo/release.json` | 3 | json |
| `domain_pack_mixed_high_reuse/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `domain_pack_mixed_high_reuse/repo_v2_cdc.cldrepo/release.json` | 3 | json |
| `domain_pack_mixed_high_reuse/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `many_small_mixed_update/alpha51_1_aggregate_summary.csv` | 1 | text |
| `many_small_mixed_update/alpha51_1_aggregate_summary.json` | 3 | json |
| `many_small_mixed_update/bench_real_result.json` | 2 | json |
| `many_small_mixed_update/bench_real_technical_report.md` | 1 | text |
| `many_small_mixed_update/repo_v1_cdc.cldrepo/release.json` | 3 | json |
| `many_small_mixed_update/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `many_small_mixed_update/repo_v2_cdc.cldrepo/release.json` | 3 | json |
| `many_small_mixed_update/repo_v2_fixed.cldrepo/release.json` | 3 | json |
| `model_pack_localized_random/alpha51_1_aggregate_summary.csv` | 1 | text |
| `model_pack_localized_random/alpha51_1_aggregate_summary.json` | 3 | json |
| `model_pack_localized_random/bench_real_result.json` | 2 | json |
| `model_pack_localized_random/bench_real_technical_report.md` | 1 | text |
| `model_pack_localized_random/repo_v1_fastcdc.cldrepo/release.json` | 3 | json |
| `model_pack_localized_random/repo_v1_fixed.cldrepo/release.json` | 3 | json |
| `model_pack_localized_random/repo_v2_fastcdc.cldrepo/release.json` | 3 | json |
| `model_pack_localized_random/repo_v2_fixed.cldrepo/release.json` | 3 | json |

## Note

This cleanup removes confusing legacy `2.0.0-alpha50.2` metadata from alpha51.1 reports and replaces it with the current public code baseline version.
It does not change the benchmark numbers.
