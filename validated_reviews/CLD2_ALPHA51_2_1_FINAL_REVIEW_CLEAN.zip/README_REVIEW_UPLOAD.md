﻿# CLD2 alpha51.2.1 synthetic matrix review upload

This is a lightweight review package.

Included:
- JSON/CSV/MD/HTML/TXT/LOG/SHA256 files
- full file inventory
- alpha51.2.1 version string polish report

Excluded:
- large generated artifacts
- heavy cache/repo data

Expected clean version string:
2.0.0-alpha50.2

Created:
2026-06-04T15:22:54.5445428+02:00
