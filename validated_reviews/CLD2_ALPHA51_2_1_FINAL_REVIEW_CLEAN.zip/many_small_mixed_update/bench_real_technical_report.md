﻿# CLD2 benchmark report — many_small_mixed_update / medium

Version: `2.0.0-alpha50.2`

## Core result

| Method | Download pack bytes | Raw chunk bytes | Chunk reuse | Reused | Added | Removed | Pack v1 | Pack v2 | Total pack | Saved vs file-level raw | Saved vs tar.zst update |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| fixed | 8954732 | 10133596 | 85.6744% | 921 | 154 | 104 | 1.8398 s | 1.9893 s | 3.8291 s | 11.6332% | 0.1693% |
| cdc | 8954732 | 10133596 | 85.6744% | 921 | 154 | 104 | 2.3039 s | 2.4171 s | 4.721 s | 11.6332% | 0.1693% |

cdc packing slowdown vs fixed: **1.23×**.

## Baseline

- V1 logical bytes: 67108933
- V2 logical bytes: 70492252
- File-level raw update bytes: 10133596
- File-level tar.gz update bytes: 8994549
- File-level tar.zst update bytes: 8969921
- Full tar.gz v2 bytes: 49546997
- Full tar.zst v2 bytes: 49389707

## Scenario metadata

```json
{
  "added_file_count": 50,
  "common_file_count": 1025,
  "new_file_count": 1075,
  "note": "Alpha18 metadata records size-level changes. Exact byte-level delta requires an explicit scenario generator or external diff.",
  "old_file_count": 1025,
  "removed_file_count": 0,
  "size_changed_file_count": 53,
  "size_changed_sample": [
    {
      "new_size": 92,
      "old_size": 69,
      "path": "index.json",
      "size_delta": 23
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_00/item_00000.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_00/item_00320.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_00/item_00640.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_00/item_00960.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_04/item_00260.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_04/item_00580.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_04/item_00900.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_08/item_00200.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_08/item_00520.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_08/item_00840.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_12/item_00140.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_12/item_00460.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_12/item_00780.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_16/item_00080.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_16/item_00400.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_16/item_00720.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_20/item_00020.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_20/item_00340.dat",
      "size_delta": 2048
    },
    {
      "new_size": 67584,
      "old_size": 65536,
      "path": "shard_20/item_00660.dat",
      "size_delta": 2048
    }
  ]
}
```

## Profile

```json
{
  "change_ratio": null,
  "chunk_avg": "256KiB",
  "chunk_max": "1MiB",
  "chunk_min": "64KiB",
  "file_size": "1MiB",
  "files": 32,
  "fixed_size": "256KiB"
}
```

## Interpretation guardrail

This benchmark compares update strategies. A large-file insertion/boundary-shift scenario is favorable to CDC and should not be marketed as universal compression. CDC is expected to help when releases share many unchanged byte ranges; it is not expected to create savings on encrypted, random, transcoded or completely rewritten data.

