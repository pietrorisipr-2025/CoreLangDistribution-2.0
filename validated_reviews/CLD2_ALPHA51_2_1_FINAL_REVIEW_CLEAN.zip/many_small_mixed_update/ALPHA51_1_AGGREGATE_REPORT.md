# CLD2 alpha51.1 — aggregate artifact benchmark report

This report is generated from `bench_real_result.json` files.

## Summary

| Scenario | Class | Best CLD2 | Raw baseline | Best conventional baseline | CLD2/raw | CLD2/conventional |
|---|---|---:|---:|---:|---:|---:|
| many_small_mixed_update | near-parity | 8.54 MiB via `fixed` | 9.66 MiB | file_level_tar_zstd_bytes: 8.55 MiB | 0.883668 | 0.998307 |

## Interpretation

### many_small_mixed_update

- Classification: **near-parity**
- Reason: CLD2 is close to the best compressed conventional baseline.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 8.54 MiB
- Raw baseline: 9.66 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 8.55 MiB

## Claim boundary

Alpha51.1 is an artifact-pair benchmark. It does not prove that CLD2 always wins. Results should be interpreted per artifact and per update pattern.
