# CLD2 distribution savings report — many_small_mixed_update

## Executive summary

This report compares file-level/full redistribution against CLD2 chunk-level updates. It is a transparent byte * downloads * egress-price estimate, not a production SLA.

- Downloads/users modelled: 1000
- Egress price model: 0.09 USD/GiB
- Cost note: Estimated egress only: bytes * downloads * cost_per_GiB. It excludes storage, requests, cache hit rates, taxes, and CDN tiering.

## Update-size comparison

| Method | Update bytes | Chunk reuse | Saved vs raw file-level | Saved vs tar.zst update | Estimated egress cost |
|---|---:|---:|---:|---:|---:|
| CLD2 fixed | 8954732 | 85.6744% | 11.6332% | 0.1693% | 0.750577 USD |
| CLD2 cdc | 8954732 | 85.6744% | 11.6332% | 0.1693% | 0.750577 USD |

## Baselines

| Baseline | Bytes | Estimated egress cost | Source |
|---|---:|---:|---|
| Full logical v2 | 70492252 | 5.909 USD | measured |
| Full tar.gz v2 | 49546997 | 4.153 USD | measured |
| Full tar.zst v2 | 49389707 | 4.140 USD | measured |
| Changed files raw | 10133596 | 0.849388 USD | measured |
| Changed files tar.gz | 8994549 | 0.753914 USD | measured |
| Changed files tar.zst | 8969921 | 0.751850 USD | measured |

## Savings projection

| Method | Saved vs changed-files raw | Saved vs changed-files tar.zst | Saved vs full tar.zst |
|---|---:|---:|---:|
| CLD2 fixed | 0.098811 USD (11.6332%) | 0.001273 USD (0.1693%) | 3.389 USD (81.8692%) |
| CLD2 cdc | 0.098811 USD (11.6332%) | 0.001273 USD (0.1693%) | 3.389 USD (81.8692%) |

## Technical details

```json
{
  "comparison": {
    "fixed_download_bytes": 8954732,
    "optimized_download_bytes": 8954732,
    "optimized_method": "cdc",
    "optimized_saved_ratio_vs_fixed": 0.0,
    "optimized_saved_vs_fixed_bytes": 0
  },
  "profile": "medium",
  "profiles": null,
  "scenario": "many_small_mixed_update"
}
```

## Interpretation guardrail

CLD2 is expected to help when release A and release B share many chunks. It is not expected to create savings on encrypted/random/completely rewritten data. Real CDN bills also depend on cache hit ratio, regions, request pricing and negotiated tiers.
