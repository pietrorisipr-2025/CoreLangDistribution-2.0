# CLD2 alpha51.1 — aggregate artifact benchmark report

This report is generated from `bench_real_result.json` files.

## Summary

| Scenario | Class | Best CLD2 | Raw baseline | Best conventional baseline | CLD2/raw | CLD2/conventional |
|---|---|---:|---:|---:|---:|---:|
| badfit_entropy_rewrite | bad-fit | 64.00 MiB via `fixed` | 64.00 MiB | full_tar_zstd_v2_bytes: 64.00 MiB | 1.000000 | 0.999972 |
| domain_pack_mixed_high_reuse | near-parity | 3.17 MiB via `cdc` | 8.50 MiB | file_level_tar_zstd_bytes: 3.18 MiB | 0.372816 | 0.995329 |
| many_small_mixed_update | near-parity | 8.54 MiB via `fixed` | 9.66 MiB | file_level_tar_zstd_bytes: 8.55 MiB | 0.883668 | 0.998307 |
| model_pack_localized_random | high-reuse-win | 2.00 MiB via `fixed` | 64.00 MiB | file_level_tar_zstd_bytes: 64.00 MiB | 0.031251 | 0.031250 |

## Interpretation

### badfit_entropy_rewrite

- Classification: **bad-fit**
- Reason: CLD2 transfers nearly the full artifact; little useful reuse.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 64.00 MiB
- Raw baseline: 64.00 MiB
- Best conventional baseline: `full_tar_zstd_v2_bytes` = 64.00 MiB

### domain_pack_mixed_high_reuse

- Classification: **near-parity**
- Reason: CLD2 is close to the best compressed conventional baseline.
- Best CLD2 method: `cdc`
- Best CLD2 bytes: 3.17 MiB
- Raw baseline: 8.50 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 3.18 MiB

### many_small_mixed_update

- Classification: **near-parity**
- Reason: CLD2 is close to the best compressed conventional baseline.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 8.54 MiB
- Raw baseline: 9.66 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 8.55 MiB

### model_pack_localized_random

- Classification: **high-reuse-win**
- Reason: CLD2 is clearly below the best conventional compressed baseline.
- Best CLD2 method: `fixed`
- Best CLD2 bytes: 2.00 MiB
- Raw baseline: 64.00 MiB
- Best conventional baseline: `file_level_tar_zstd_bytes` = 64.00 MiB

## Claim boundary

Alpha51.1 is an artifact-pair benchmark. It does not prove that CLD2 always wins. Results should be interpreted per artifact and per update pattern.
