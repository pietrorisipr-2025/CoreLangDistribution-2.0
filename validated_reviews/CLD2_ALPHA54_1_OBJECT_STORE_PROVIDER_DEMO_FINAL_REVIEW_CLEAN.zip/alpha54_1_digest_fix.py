﻿import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime, timezone

out_root = Path(sys.argv[1]).resolve()
expected_root = out_root / "work" / "small_demo" / "release_v2"
install_root = out_root / "install_v2"
old_result_path = out_root / "alpha54_object_store_provider_result.json"

def tree_sha256(root, exclude_dirs=None):
    exclude_dirs = set(exclude_dirs or [])
    root = Path(root)
    h = hashlib.sha256()
    count = 0
    total = 0
    files = []

    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue

        rel_parts = p.relative_to(root).parts
        if any(part in exclude_dirs for part in rel_parts):
            continue

        rel = p.relative_to(root).as_posix()
        data = p.read_bytes()
        digest = hashlib.sha256(data).hexdigest()

        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(digest.encode("ascii"))
        h.update(b"\n")

        count += 1
        total += len(data)
        files.append({"path": rel, "bytes": len(data), "sha256": digest})

    return {
        "sha256": h.hexdigest(),
        "files": count,
        "bytes": total,
        "file_list": files,
    }

with old_result_path.open("r", encoding="utf-8-sig") as f:
    old = json.load(f)

expected = tree_sha256(expected_root)
actual = tree_sha256(install_root, exclude_dirs={".cld2"})

fetch_ok = bool(old.get("fetch_ok"))
audit_install_ok = bool(old.get("audit_install_ok"))
digest_ok = expected["sha256"] == actual["sha256"]
ok = fetch_ok and audit_install_ok and digest_ok

result = {
    "schema": "CLD2/alpha54_1_object_store_provider_result",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "code_baseline": "2.0.0-alpha50.2",
    "benchmark_milestone": "alpha54.1",
    "ok": ok,
    "fetch_ok": fetch_ok,
    "audit_install_ok": audit_install_ok,
    "digest_ok": digest_ok,
    "object_store_kind": old.get("object_store_kind", "local-directory-object-store-like"),
    "fix": "tree digest excludes install metadata directory .cld2",
    "expected_tree_sha256": expected["sha256"],
    "actual_tree_sha256": actual["sha256"],
    "expected_files": expected["files"],
    "actual_files": actual["files"],
    "expected_bytes": expected["bytes"],
    "actual_bytes": actual["bytes"],
    "expected_file_list": expected["file_list"],
    "actual_file_list": actual["file_list"],
    "previous_alpha54_result": {
        "ok": old.get("ok"),
        "fetch_ok": old.get("fetch_ok"),
        "audit_install_ok": old.get("audit_install_ok"),
        "digest_ok": old.get("digest_ok"),
        "expected_tree_sha256": old.get("expected_tree_sha256"),
        "actual_tree_sha256": old.get("actual_tree_sha256"),
        "expected_files": old.get("expected_files"),
        "actual_files": old.get("actual_files"),
        "note": "previous actual digest included .cld2 metadata files",
    },
    "claim_boundary": [
        "This is a local object-store-like directory demo.",
        "It is not a real S3/MinIO/CDN performance benchmark.",
        "alpha54.1 fixes the digest comparison by excluding .cld2 install metadata."
    ],
}

summary = {
    "schema": "CLD2/alpha54_1_object_store_provider_summary",
    "ok": ok,
    "fetch_ok": fetch_ok,
    "audit_install_ok": audit_install_ok,
    "digest_ok": digest_ok,
    "code_baseline": "2.0.0-alpha50.2",
    "benchmark_milestone": "alpha54.1",
    "expected_tree_sha256": expected["sha256"],
    "actual_tree_sha256": actual["sha256"],
    "expected_files": expected["files"],
    "actual_files": actual["files"],
    "expected_bytes": expected["bytes"],
    "actual_bytes": actual["bytes"],
    "fix": "excluded .cld2 metadata directory from installed tree digest",
}

(out_root / "alpha54_1_object_store_provider_result.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n",
    encoding="utf-8"
)

(out_root / "alpha54_1_object_store_provider_summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n",
    encoding="utf-8"
)

report = f"""# CLD2 alpha54.1 — Object-store-like provider digest fix

## Verdict

- Fetch OK: {fetch_ok}
- Audit-install OK: {audit_install_ok}
- Digest OK: {digest_ok}
- Overall OK: {ok}

## Fix

Alpha54 computed the installed tree digest including `.cld2` metadata files.
Alpha54.1 computes the installed payload digest excluding `.cld2`.

## Claim boundary

This is still a local object-store-like demo.
It is not a real S3, MinIO, CDN or cloud performance benchmark.
"""

(out_root / "ALPHA54_1_OBJECT_STORE_PROVIDER_DEMO_REPORT.md").write_text(report, encoding="utf-8")

print(json.dumps(summary, indent=2, sort_keys=True))
sys.exit(0 if ok else 2)
