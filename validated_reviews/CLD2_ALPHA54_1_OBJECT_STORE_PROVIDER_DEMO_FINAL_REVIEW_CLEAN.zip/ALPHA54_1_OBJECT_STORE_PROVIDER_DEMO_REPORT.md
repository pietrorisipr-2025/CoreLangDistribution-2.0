# CLD2 alpha54.1 — Object-store-like provider digest fix

## Verdict

- Fetch OK: True
- Audit-install OK: True
- Digest OK: True
- Overall OK: True

## Fix

Alpha54 computed the installed tree digest including `.cld2` metadata files.
Alpha54.1 computes the installed payload digest excluding `.cld2`.

## Claim boundary

This is still a local object-store-like demo.
It is not a real S3, MinIO, CDN or cloud performance benchmark.
