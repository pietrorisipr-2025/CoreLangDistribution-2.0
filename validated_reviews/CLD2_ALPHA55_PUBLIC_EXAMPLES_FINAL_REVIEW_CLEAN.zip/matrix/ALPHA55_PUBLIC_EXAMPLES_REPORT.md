# CLD2 alpha55 — Public examples report

## Verdict

Overall OK: `True`

## Summary

| Scenario | OK | Classification | full v2 payload bytes | warm downloaded pack bytes | audit OK | digest OK |
|---|---:|---|---:|---:|---:|---:|
| game_asset_patch | True | high-reuse-win | 53444758 | 1263 | True | True |
| model_profile_pack | True | high-reuse-win | 60492302 | 1501151 | True | True |
| ci_artifact_bundle | True | high-reuse-win | 44228056 | 3561 | True | True |

## Claim boundary

These are local generated public examples. They are not a cloud/CDN/S3/MinIO performance benchmark and not an external security audit.
