# game_asset_patch

Game-like asset tree with localized changes and added assets.
