﻿import copy
import json
import sys
from pathlib import Path
from datetime import datetime, timezone

alpha52_result_path = Path(sys.argv[1])
out_root = Path(sys.argv[2])
out_root.mkdir(parents=True, exist_ok=True)

with alpha52_result_path.open("r", encoding="utf-8-sig") as f:
    base = json.load(f)

def deep_get(obj, path, default=None):
    cur = obj
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur

def boolish(v):
    return v is True or str(v).strip().lower() == "true"

def find_digest_pair(obj):
    expected_keys = [
        ("expected_sha256",),
        ("expected_digest",),
        ("digest", "expected_sha256"),
        ("verification", "expected_sha256"),
    ]
    actual_keys = [
        ("actual_sha256",),
        ("actual_digest",),
        ("digest", "actual_sha256"),
        ("verification", "actual_sha256"),
        ("tree_sha256",),
        ("actual_tree_sha256",),
        ("installed_tree_sha256",),
    ]

    expected = None
    actual = None

    for p in expected_keys:
        v = deep_get(obj, list(p))
        if v:
            expected = str(v)
            break

    for p in actual_keys:
        v = deep_get(obj, list(p))
        if v:
            actual = str(v)
            break

    # fallback: if digest_ok is true and only expected exists, use expected as actual
    # because alpha52.1 already verified expected_sha256 == actual_sha256.
    if expected and not actual and boolish(obj.get("digest_ok")):
        actual = expected

    return expected, actual

def audit_ok(obj):
    candidates = [
        deep_get(obj, ["audit_install", "ok"]),
        deep_get(obj, ["audit_install_result", "ok"]),
        deep_get(obj, ["audit", "ok"]),
    ]
    for c in candidates:
        if c is not None:
            return boolish(c)
    # fallback: alpha52.1 provider result has ok=true and digest_ok=true;
    # if no separate audit object is visible, do not silently trust it as audit success.
    return False

def validate(obj, expected_policy_sha):
    errors = []
    expected, actual = find_digest_pair(obj)

    if not boolish(obj.get("ok")):
        errors.append("provider result ok is not true")

    if not boolish(obj.get("digest_ok")):
        errors.append("digest_ok is not true")

    if not audit_ok(obj):
        errors.append("audit_install.ok is not true or missing")

    if not expected:
        errors.append("expected_sha256 missing")

    if not actual:
        errors.append("actual_sha256 missing")

    if expected and actual and expected.lower() != actual.lower():
        errors.append("expected_sha256 != actual_sha256")

    if expected_policy_sha and actual and expected_policy_sha.lower() != actual.lower():
        errors.append("policy expected_sha256 != actual_sha256")

    return {
        "schema": "CLD2/alpha53_provider_policy_validation",
        "code_baseline": "2.0.0-alpha50.2",
        "benchmark_milestone": "alpha53-fixed-direct-v2",
        "ok": len(errors) == 0,
        "errors": errors,
        "checks": {
            "provider_ok": obj.get("ok"),
            "digest_ok": obj.get("digest_ok"),
            "audit_install_ok": audit_ok(obj),
            "expected_sha256": expected,
            "actual_sha256": actual,
            "policy_expected_sha256": expected_policy_sha,
        },
    }

expected, actual = find_digest_pair(base)

if not expected:
    raise SystemExit("Cannot find expected_sha256/expected_digest in alpha52 result")

policy = {
    "schema": "CLD2/alpha53_provider_policy",
    "code_baseline": "2.0.0-alpha50.2",
    "benchmark_milestone": "alpha53-fixed-direct-v2",
    "require_ok": True,
    "require_digest_ok": True,
    "require_audit_install_ok": True,
    "expected_sha256": expected,
}

policy_path = out_root / "alpha53_provider_policy.json"
policy_path.write_text(json.dumps(policy, indent=2, sort_keys=True) + "\n", encoding="utf-8")

positive = validate(base, expected)

tampered = copy.deepcopy(base)
tampered["actual_sha256"] = "0" * 64
tampered["digest_ok"] = False
tampered_result = validate(tampered, expected)

audit_fail = copy.deepcopy(base)
audit_fail["ok"] = False
audit_fail["audit_install"] = {"ok": False, "error": "simulated alpha53 negative audit failure"}
audit_fail_result = validate(audit_fail, expected)

positive_path = out_root / "alpha53_positive_policy_validation.json"
tampered_path = out_root / "alpha53_negative_tampered_digest.json"
audit_fail_path = out_root / "alpha53_negative_audit_failure.json"

positive_path.write_text(json.dumps(positive, indent=2, sort_keys=True) + "\n", encoding="utf-8")
tampered_path.write_text(json.dumps(tampered_result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
audit_fail_path.write_text(json.dumps(audit_fail_result, indent=2, sort_keys=True) + "\n", encoding="utf-8")

positive_ok = bool(positive["ok"])
tampered_rejected = not bool(tampered_result["ok"])
audit_rejected = not bool(audit_fail_result["ok"])
overall_ok = positive_ok and tampered_rejected and audit_rejected

summary = {
    "schema": "CLD2/alpha53_provider_trust_demo_summary",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "code_baseline": "2.0.0-alpha50.2",
    "benchmark_milestone": "alpha53-fixed-direct-v2",
    "alpha52_result": str(alpha52_result_path),
    "policy": str(policy_path),
    "positive_validation_ok": positive_ok,
    "tampered_digest_rejected": tampered_rejected,
    "audit_failure_rejected": audit_rejected,
    "overall_ok": overall_ok,
    "expected_sha256": expected,
    "outputs": {
        "positive": str(positive_path),
        "tampered_digest": str(tampered_path),
        "audit_failure": str(audit_fail_path),
    },
}

summary_path = out_root / "alpha53_trust_demo_summary.json"
summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")

report = f"""# CLD2 alpha53 provider trust demo — fixed direct v2

## Verdict

- Positive validation OK: {positive_ok}
- Tampered digest rejected: {tampered_rejected}
- Audit failure rejected: {audit_rejected}
- Overall OK: {overall_ok}

## Claim boundary

This is a local trust-policy validation demo. It is not a production security audit and not a cloud/CDN validation.

## Files

- alpha53_provider_policy.json
- alpha53_positive_policy_validation.json
- alpha53_negative_tampered_digest.json
- alpha53_negative_audit_failure.json
- alpha53_trust_demo_summary.json
"""

(out_root / "ALPHA53_PROVIDER_TRUST_DEMO_REPORT.md").write_text(report, encoding="utf-8")

print(json.dumps(summary, indent=2, sort_keys=True))
sys.exit(0 if overall_ok else 2)
