#!/usr/bin/env bash
set -Eeuo pipefail

OUT_LINUX="$1"
TMP="/tmp/cld2_alpha48_dvc_microbaseline_64MiB"
VENV="/tmp/cld2_alpha48_dvc_venv"

rm -rf "$TMP"
mkdir -p "$TMP"
mkdir -p "$OUT_LINUX"

cat > "$TMP/alpha48_dvc_runner.py" <<'PY'
import csv
import hashlib
import json
import os
import random
import shutil
import subprocess
import tarfile
import time
from pathlib import Path

OUT = Path(os.environ["CLD2_ALPHA48_OUT"])
DVC = Path(os.environ["CLD2_DVC_BIN"])
TMP = Path("/tmp/cld2_alpha48_dvc_microbaseline_64MiB/work")
TMP.mkdir(parents=True, exist_ok=True)

FILE_SIZE = 64 * 1024 * 1024
SMALL_FILE_COUNT = 256
SCENARIOS = ["normal", "high-entropy", "small-files", "heavy-change"]

def sha256_file(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def tree_hashes(root):
    out = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            out[p.relative_to(root).as_posix()] = sha256_file(p)
    return out

def tree_size(root):
    return sum(p.stat().st_size for p in root.rglob("*") if p.is_file())

def dir_bytes(path):
    if not path.exists():
        return 0
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())

def count_files(path):
    if not path.exists():
        return 0
    return sum(1 for p in path.rglob("*") if p.is_file())

def run(cmd, cwd=None, timeout=1800):
    t0 = time.time()
    p = subprocess.run(
        [str(x) for x in cmd],
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        env={**os.environ, "DVC_NO_ANALYTICS": "1"},
    )
    return {
        "cmd": [str(x) for x in cmd],
        "returncode": p.returncode,
        "ok": p.returncode == 0,
        "seconds": round(time.time() - t0, 3),
        "stdout_tail": p.stdout[-4000:],
        "stderr_tail": p.stderr[-4000:],
    }

def fill_file(path, size, seed=1, pattern=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    remaining = int(size)
    rnd = random.Random(seed)
    with path.open("wb") as f:
        if pattern:
            while remaining > 0:
                chunk = pattern[:min(len(pattern), remaining)]
                f.write(chunk)
                remaining -= len(chunk)
        else:
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(rnd.randbytes(n))
                remaining -= n

def write_pair(root, scenario):
    v1 = root / "v1"
    v2 = root / "v2"
    if root.exists():
        shutil.rmtree(root)
    v1.mkdir(parents=True)
    v2.mkdir(parents=True)

    if scenario == "normal":
        block = (b"CLD2_ALPHA33_HTTP_RANGE_ETAG_PILOT\n" * 1024)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=block)
        (v1 / "config").mkdir()
        (v1 / "config" / "settings.json").write_text(
            json.dumps({"version": 1, "mode": "old", "features": ["range", "etag"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        blob = bytearray((v2 / "data.bin").read_bytes())
        start = max(0, len(blob) // 2 - 2048)
        patch = b"CLD2_ALPHA33_LOCALIZED_UPDATE" * 128
        blob[start:start + len(patch)] = patch
        (v2 / "data.bin").write_bytes(bytes(blob))
        (v2 / "config" / "settings.json").write_text(
            json.dumps({"version": 2, "mode": "new", "features": ["range", "etag", "resume"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        return v1, v2

    if scenario == "high-entropy":
        fill_file(v1 / "entropy.bin", FILE_SIZE, seed=404)
        fill_file(v2 / "entropy.bin", FILE_SIZE, seed=405)
        (v1 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 1}) + "\n", encoding="utf-8")
        (v2 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 2, "note": "unrelated entropy"}) + "\n", encoding="utf-8")
        return v1, v2

    if scenario == "heavy-change":
        pattern = (b"CLD2_ALPHA40_HEAVY_CHANGE_STRUCTURED_BLOCK\n" * 4096)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=pattern)
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        p = v2 / "data.bin"
        start = FILE_SIZE // 3
        length = max(1, int(FILE_SIZE * 0.40))
        rnd = random.Random(909)
        with p.open("r+b") as f:
            f.seek(start)
            remaining = min(length, FILE_SIZE - start)
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(rnd.randbytes(n))
                remaining -= n
        (v2 / "change.log").write_text("heavy-change: middle region rewritten\n", encoding="utf-8")
        return v1, v2

    if scenario == "small-files":
        count = SMALL_FILE_COUNT
        per = max(128, FILE_SIZE // count)
        total = 0
        for i in range(count):
            group = f"group_{i % 16:02d}"
            name = f"file_{i:05d}.dat"
            payload = (f"CLD2 alpha40 small file {i}\n".encode("utf-8") * 256)
            this_size = min(per, max(128, FILE_SIZE - total)) if total < FILE_SIZE else per
            fill_file(v1 / group / name, this_size, seed=i, pattern=payload)
            total += this_size
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        for i in range(max(1, count // 10)):
            p = v2 / f"group_{i % 16:02d}" / f"file_{i:05d}.dat"
            if p.exists():
                with p.open("ab") as f:
                    f.write((f"\nUPDATED small-file {i}\n".encode("utf-8") * 64))
        for j in range(max(1, count // 20)):
            idx = count + j
            fill_file(v2 / "added" / f"added_{idx:05d}.dat", per, seed=2000 + j, pattern=(b"ADDED_ALPHA40_SMALL_FILE\n" * 128))
        return v1, v2

    raise ValueError(f"unknown scenario: {scenario}")

def make_deterministic_tar(src, dst):
    if dst.exists():
        dst.unlink()
    with tarfile.open(dst, "w") as tf:
        for p in sorted(src.rglob("*")):
            arc = p.relative_to(src).as_posix()
            info = tf.gettarinfo(str(p), arcname=arc)
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            if p.is_file():
                info.mode = 0o644
                with p.open("rb") as f:
                    tf.addfile(info, f)
            elif p.is_dir():
                info.mode = 0o755
                tf.addfile(info)
    return {"path": str(dst), "bytes": dst.stat().st_size, "sha256": sha256_file(dst)}

def run_scenario(scenario):
    sroot = TMP / scenario
    pair_root = sroot / "pair"
    repo = sroot / "dvc_repo"
    remote = sroot / "dvc_remote"
    client = sroot / "dvc_client"

    if sroot.exists():
        shutil.rmtree(sroot)
    sroot.mkdir(parents=True)

    v1, v2 = write_pair(pair_root, scenario)
    tar_info = make_deterministic_tar(v2, sroot / f"{scenario}_v2.tar")

    repo.mkdir(parents=True)
    remote.mkdir(parents=True)

    init = run([DVC, "init", "--no-scm"], cwd=repo, timeout=600)
    remote_add = run([DVC, "remote", "add", "-d", "localremote", str(remote)], cwd=repo, timeout=600)

    shutil.copytree(v1, repo / "data")
    add_v1 = run([DVC, "add", "data", "--force"], cwd=repo, timeout=1800)
    push_v1 = run([DVC, "push", "-r", "localremote"], cwd=repo, timeout=1800)
    remote_bytes_v1 = dir_bytes(remote)
    remote_files_v1 = count_files(remote)

    # Replace working data with v2 and push again.
    shutil.rmtree(repo / "data")
    shutil.copytree(v2, repo / "data")
    add_v2 = run([DVC, "add", "data", "--force"], cwd=repo, timeout=1800)
    push_v2 = run([DVC, "push", "-r", "localremote"], cwd=repo, timeout=1800)
    remote_bytes_v2 = dir_bytes(remote)
    remote_files_v2 = count_files(remote)

    dvc_new_remote_bytes = remote_bytes_v2 - remote_bytes_v1
    dvc_new_remote_files = remote_files_v2 - remote_files_v1

    # Verify by pulling v2 into a clean DVC repo using the generated data.dvc file.
    client.mkdir(parents=True)
    client_init = run([DVC, "init", "--no-scm"], cwd=client, timeout=600)
    client_remote_add = run([DVC, "remote", "add", "-d", "localremote", str(remote)], cwd=client, timeout=600)
    shutil.copy2(repo / "data.dvc", client / "data.dvc")
    pull_v2 = run([DVC, "pull", "-r", "localremote"], cwd=client, timeout=1800)

    expected = tree_hashes(v2)
    got = tree_hashes(client / "data") if (client / "data").exists() else {}
    verify = {
        "ok": expected == got,
        "missing": sorted(set(expected) - set(got)),
        "extra": sorted(set(got) - set(expected)),
        "mismatch": sorted(k for k in set(expected) & set(got) if expected[k] != got[k]),
    }

    full_tree_bytes = tree_size(v2)

    result = {
        "scenario": scenario,
        "ok": bool(
            init["ok"] and remote_add["ok"] and
            add_v1["ok"] and push_v1["ok"] and
            add_v2["ok"] and push_v2["ok"] and
            client_init["ok"] and client_remote_add["ok"] and pull_v2["ok"] and
            verify["ok"]
        ),
        "tool": "dvc",
        "mode": "local DVC remote; metric is new remote bytes added by v2 after v1 was pushed",
        "file_size_target": FILE_SIZE,
        "small_file_count": SMALL_FILE_COUNT,
        "dvc_remote_bytes_after_v1": remote_bytes_v1,
        "dvc_remote_bytes_after_v2": remote_bytes_v2,
        "dvc_new_remote_bytes_v2_minus_v1": dvc_new_remote_bytes,
        "dvc_remote_files_after_v1": remote_files_v1,
        "dvc_remote_files_after_v2": remote_files_v2,
        "dvc_new_remote_files_v2_minus_v1": dvc_new_remote_files,
        "dvc_vs_full_tree_ratio": (dvc_new_remote_bytes / full_tree_bytes) if full_tree_bytes else None,
        "dvc_vs_full_tar_ratio": (dvc_new_remote_bytes / tar_info["bytes"]) if tar_info["bytes"] else None,
        "full_v2_tree_bytes": full_tree_bytes,
        "full_v2_tar": tar_info,
        "verify": verify,
        "commands": {
            "init": init,
            "remote_add": remote_add,
            "add_v1": add_v1,
            "push_v1": push_v1,
            "add_v2": add_v2,
            "push_v2": push_v2,
            "client_init": client_init,
            "client_remote_add": client_remote_add,
            "pull_v2": pull_v2,
        },
        "claim_boundary_note": "DVC stores file/directory cache objects; this is not an HTTP byte benchmark and not an exact equivalent of CLD2 warm chunk/object planning.",
    }

    scen_out = OUT / scenario
    scen_out.mkdir(parents=True, exist_ok=True)
    (scen_out / "dvc_scenario_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result

def write_outputs(results):
    summary_csv = OUT / "dvc_microbaseline_summary.csv"
    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "scenario", "ok",
            "dvc_new_remote_bytes_v2_minus_v1",
            "full_v2_tree_bytes",
            "full_v2_tar_bytes",
            "dvc_vs_full_tree_ratio",
            "dvc_vs_full_tar_ratio",
            "dvc_new_remote_files_v2_minus_v1",
            "dvc_remote_bytes_after_v1",
            "dvc_remote_bytes_after_v2"
        ])
        w.writeheader()
        for r in results:
            w.writerow({
                "scenario": r["scenario"],
                "ok": r["ok"],
                "dvc_new_remote_bytes_v2_minus_v1": r["dvc_new_remote_bytes_v2_minus_v1"],
                "full_v2_tree_bytes": r["full_v2_tree_bytes"],
                "full_v2_tar_bytes": r["full_v2_tar"]["bytes"],
                "dvc_vs_full_tree_ratio": r["dvc_vs_full_tree_ratio"],
                "dvc_vs_full_tar_ratio": r["dvc_vs_full_tar_ratio"],
                "dvc_new_remote_files_v2_minus_v1": r["dvc_new_remote_files_v2_minus_v1"],
                "dvc_remote_bytes_after_v1": r["dvc_remote_bytes_after_v1"],
                "dvc_remote_bytes_after_v2": r["dvc_remote_bytes_after_v2"],
            })

    all_json = {
        "schema": "CLD2/alpha48_dvc_microbaseline",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool_status": {
            "dvc": "available and benchmarked",
            "lakefs": "not benchmarked",
            "xet": "not benchmarked",
        },
        "benchmark_kind": "alpha48 test/positioning milestone, not CLD2 software release",
        "metric": "new bytes added to local DVC remote by v2 after v1 was already pushed",
        "scenarios": results,
        "claim_boundary": [
            "DVC is measured as local remote cache growth, not HTTP response bytes.",
            "DVC is file/directory versioning, not an exact CLD2 warm object/chunk planner equivalent.",
            "DVC can be valuable for data versioning even if it is not optimized for intra-file delta updates.",
            "Do not claim CLD2 always beats DVC; compare per workload and per purpose."
        ],
    }
    (OUT / "dvc_microbaseline_result.json").write_text(json.dumps(all_json, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rows = []
    for r in results:
        rows.append(
            f"| {r['scenario']} | {r['ok']} | {r['dvc_new_remote_bytes_v2_minus_v1']} | "
            f"{r['full_v2_tree_bytes']} | {r['full_v2_tar']['bytes']} | "
            f"{r['dvc_vs_full_tree_ratio']} | {r['dvc_vs_full_tar_ratio']} | "
            f"{r['dvc_new_remote_files_v2_minus_v1']} |"
        )

    md = f"""# CLD2 alpha48 ? DVC micro-baseline

## Verdict

- `DVC`: available and benchmarked.
- `lakeFS`: not benchmarked.
- `Xet/git-xet`: not benchmarked.
- Mode: local DVC remote; metric is remote byte growth from v1 to v2.
- Alpha48 is a benchmark/positioning milestone, not a CLD2 software release.

## Summary

| Scenario | OK | DVC new remote bytes | full v2 tree bytes | full v2 tar bytes | DVC/full tree | DVC/full tar | new remote files |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

## Claim boundary

This is not an HTTP byte benchmark.
DVC is a data-versioning/cache system with file/directory granularity, so this baseline is useful for positioning, not as a perfectly homogeneous replacement for zsync/casync/OSTree/CLD2.
"""
    (OUT / "BASELINE_REPORT.md").write_text(md, encoding="utf-8")
    (OUT / "index.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>CLD2 alpha48 DVC micro-baseline</title>"
        "<pre>" + md.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</pre>",
        encoding="utf-8"
    )

def main():
    preflight = run([DVC, "--version"], timeout=60)
    (OUT / "preflight_after_install.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not preflight["ok"]:
        raise SystemExit("DVC not available inside WSL venv")

    results = []
    for s in SCENARIOS:
        print(f"=== alpha48 DVC scenario: {s} ===", flush=True)
        results.append(run_scenario(s))
    write_outputs(results)

if __name__ == "__main__":
    main()
PY

if [ ! -x "$VENV/bin/dvc" ]; then
  echo "DVC venv missing: $VENV/bin/dvc"
  echo "Run the DVC install/check step again."
  exit 2
fi

export CLD2_ALPHA48_OUT="$OUT_LINUX"
export CLD2_DVC_BIN="$VENV/bin/dvc"

"$VENV/bin/python" "$TMP/alpha48_dvc_runner.py" 2>&1 | tee "$OUT_LINUX/alpha48_dvc_runner_raw.log"
