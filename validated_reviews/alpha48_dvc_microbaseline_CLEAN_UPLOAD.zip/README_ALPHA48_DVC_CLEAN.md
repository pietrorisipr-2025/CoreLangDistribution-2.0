# CLD2 alpha48 — DVC micro-baseline CLEAN package
## Status
- DVC: available and benchmarked.
- lakeFS: not benchmarked.
- Xet/git-xet: not benchmarked.
- Alpha48 is a benchmark/positioning milestone, not a CLD2 software release.
## Main metric
DVC was measured as **new bytes added to a local DVC remote by v2 after v1 was already pushed**. This is not an HTTP response-byte benchmark and is not perfectly equivalent to CLD2/zsync/casync/OSTree.
## DVC summary
| Scenario | OK | DVC new remote bytes | Full v2 tree bytes | DVC/full tree |
|---|---:|---:|---:|---:|
| normal | True | 67,109,107 | 67,108,959 | 1.000002 |
| high-entropy | True | 67,109,076 | 67,108,936 | 1.000002 |
| small-files | True | 6,874,124 | 70,290,752 | 0.097796 |
| heavy-change | True | 67,109,040 | 67,108,902 | 1.000002 |

## Comparison table
| Scenario | DVC new remote | CLD2 warm | zsync HTTP | casync HTTP | OSTree HTTP update |
|---|---:|---:|---:|---:|---:|
| normal | 67,109,107 | 419 | 239,827 | 10,986 | 196,227 |
| high-entropy | 67,109,076 | 67,108,937 | 67,342,559 | 67,160,433 | 67,130,107 |
| small-files | 6,874,124 | 2,147 | 3,515,724 | 55,116 | 34,554 |
| heavy-change | 67,109,040 | 26,845,855 | 27,078,879 | 26,871,717 | 26,971,645 |

## Honest reading
- DVC is poor for localized edits inside one large file in this setup: it effectively stores the changed large file again.
- DVC does better in `small-files` because only a subset of file objects changes.
- DVC remains valuable as data-versioning tooling, but not as a close competitor to CLD2's warm chunk/object planner for intra-file update efficiency.
- Do not claim CLD2 always beats DVC; compare per purpose. In this tested workload, CLD2 is vastly more byte-efficient in normal/small-files and similar-to-better in hostile scenarios.
