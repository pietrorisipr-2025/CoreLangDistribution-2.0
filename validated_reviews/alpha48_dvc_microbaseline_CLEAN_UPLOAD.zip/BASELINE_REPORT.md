# CLD2 alpha48 ? DVC micro-baseline

## Verdict

- `DVC`: available and benchmarked.
- `lakeFS`: not benchmarked.
- `Xet/git-xet`: not benchmarked.
- Mode: local DVC remote; metric is remote byte growth from v1 to v2.
- Alpha48 is a benchmark/positioning milestone, not a CLD2 software release.

## Summary

| Scenario | OK | DVC new remote bytes | full v2 tree bytes | full v2 tar bytes | DVC/full tree | DVC/full tar | new remote files |
|---|---:|---:|---:|---:|---:|---:|---:|
| normal | True | 67109107 | 67108959 | 67112960 | 1.0000022053687347 | 0.9999425893299894 | 3 |
| high-entropy | True | 67109076 | 67108936 | 67112960 | 1.000002086160329 | 0.9999421274221849 | 3 |
| small-files | True | 6874124 | 70290752 | 70440960 | 0.09779556775833043 | 0.0975870289104521 | 27 |
| heavy-change | True | 67109040 | 67108902 | 67112960 | 1.0000020563590803 | 0.9999415910131217 | 3 |

## Claim boundary

This is not an HTTP byte benchmark.
DVC is a data-versioning/cache system with file/directory granularity, so this baseline is useful for positioning, not as a perfectly homogeneous replacement for zsync/casync/OSTree/CLD2.
