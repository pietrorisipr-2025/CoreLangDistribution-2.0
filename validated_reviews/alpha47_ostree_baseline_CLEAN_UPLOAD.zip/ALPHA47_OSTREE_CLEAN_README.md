# CLD2 alpha47 — OSTree baseline CLEAN package

## Status

- OSTree was available and benchmarked.
- All four scenarios completed with OK=True.
- This is a benchmark/test milestone, not a new CLD2 software release.
- No OSTree static-delta was generated in this first baseline.
- Benchmark mode: HTTP pull of `cld2/v2` after the client already pulled `cld2/v1`.

## Alpha47 OSTree results

| Scenario | OSTree HTTP update bytes | Full v2 tree bytes | OSTree/full tree | Requests | OK |
|---|---:|---:|---:|---:|---:|
| normal | 196227 | 67108959 | 0.002924006018332068 | 7 | True |
| high-entropy | 67130107 | 67108936 | 1.0003154721451701 | 6 | True |
| small-files | 34554 | 70290752 | 0.0004915867168414986 | 47 | True |
| heavy-change | 26971645 | 67108902 | 0.4019086022298502 | 6 | True |

## Comparison against already validated baselines

| Scenario | OSTree bytes | CLD2 warm bytes | zsync HTTP bytes | casync HTTP bytes | Reading |
|---|---:|---:|---:|---:|---|
| normal | 196227 | 419 | 239827 | 10986 | CLD2 is much smaller than OSTree; OSTree slightly smaller than zsync but larger than casync. |
| high-entropy | 67130107 | 67108937 | 67342559 | 67160433 | All tools are near full transfer; no strong advantage. |
| small-files | 34554 | 2147 | 3515724 | 55116 | CLD2 remains best; OSTree is much better than zsync and better than casync in this run. |
| heavy-change | 26971645 | 26845855 | 27078879 | 26871717 | All tools are very close; no strong advantage. |

## Claim boundary

This does not prove that CLD2 beats OSTree in general. OSTree here was measured as object-level HTTP pull without static deltas, while CLD2 warm numbers come from the already validated chunk/object planner matrix. The fair claim remains workload-dependent: CLD2 is strongest when chunk/object reuse is high, and roughly near the baselines in high-entropy/heavy-change cases.

## File hygiene

The uploaded ZIP contained a raw-log file with a trailing special character in the filename. This clean package normalizes it to:

`alpha47_ostree_runner_raw.log`
