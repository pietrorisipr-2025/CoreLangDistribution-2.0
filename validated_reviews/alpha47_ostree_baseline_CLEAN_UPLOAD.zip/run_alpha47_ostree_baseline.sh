#!/usr/bin/env bash
set -Eeuo pipefail

OUT_LINUX="$1"
TMP="/tmp/cld2_alpha47_ostree_baseline_64MiB"

rm -rf "$TMP"
mkdir -p "$TMP"
mkdir -p "$OUT_LINUX"

cat > "$TMP/alpha47_ostree_runner.py" <<'PY'
import csv
import hashlib
import http.server
import json
import os
import random
import shutil
import socketserver
import subprocess
import tarfile
import threading
import time
from pathlib import Path

OUT = Path(os.environ["CLD2_ALPHA47_OUT"])
TMP = Path("/tmp/cld2_alpha47_ostree_baseline_64MiB/work")
TMP.mkdir(parents=True, exist_ok=True)

FILE_SIZE = 64 * 1024 * 1024
SMALL_FILE_COUNT = 256
SCENARIOS = ["normal", "high-entropy", "small-files", "heavy-change"]

def sha256_file(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def tree_hashes(root):
    out = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            out[p.relative_to(root).as_posix()] = sha256_file(p)
    return out

def tree_size(root):
    return sum(p.stat().st_size for p in root.rglob("*") if p.is_file())

def fill_file(path, size, seed=1, pattern=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    remaining = int(size)
    rnd = random.Random(seed)
    with path.open("wb") as f:
        if pattern:
            while remaining > 0:
                chunk = pattern[:min(len(pattern), remaining)]
                f.write(chunk)
                remaining -= len(chunk)
        else:
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(bytes(rnd.getrandbits(8) for _ in range(n)))
                remaining -= n

def write_pair(root, scenario):
    v1 = root / "v1"
    v2 = root / "v2"
    if root.exists():
        shutil.rmtree(root)
    v1.mkdir(parents=True)
    v2.mkdir(parents=True)

    if scenario == "normal":
        block = (b"CLD2_ALPHA33_HTTP_RANGE_ETAG_PILOT\n" * 1024)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=block)
        (v1 / "config").mkdir()
        (v1 / "config" / "settings.json").write_text(
            json.dumps({"version": 1, "mode": "old", "features": ["range", "etag"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        blob = bytearray((v2 / "data.bin").read_bytes())
        start = max(0, len(blob) // 2 - 2048)
        patch = b"CLD2_ALPHA33_LOCALIZED_UPDATE" * 128
        blob[start:start + len(patch)] = patch
        (v2 / "data.bin").write_bytes(bytes(blob))
        (v2 / "config" / "settings.json").write_text(
            json.dumps({"version": 2, "mode": "new", "features": ["range", "etag", "resume"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        return v1, v2

    if scenario == "high-entropy":
        fill_file(v1 / "entropy.bin", FILE_SIZE, seed=404)
        fill_file(v2 / "entropy.bin", FILE_SIZE, seed=405)
        (v1 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 1}) + "\n", encoding="utf-8")
        (v2 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 2, "note": "unrelated entropy"}) + "\n", encoding="utf-8")
        return v1, v2

    if scenario == "heavy-change":
        pattern = (b"CLD2_ALPHA40_HEAVY_CHANGE_STRUCTURED_BLOCK\n" * 4096)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=pattern)
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        p = v2 / "data.bin"
        start = FILE_SIZE // 3
        length = max(1, int(FILE_SIZE * 0.40))
        rnd = random.Random(909)
        with p.open("r+b") as f:
            f.seek(start)
            remaining = min(length, FILE_SIZE - start)
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(bytes(rnd.getrandbits(8) for _ in range(n)))
                remaining -= n
        (v2 / "change.log").write_text("heavy-change: middle region rewritten\n", encoding="utf-8")
        return v1, v2

    if scenario == "small-files":
        count = SMALL_FILE_COUNT
        per = max(128, FILE_SIZE // count)
        total = 0
        for i in range(count):
            group = f"group_{i % 16:02d}"
            name = f"file_{i:05d}.dat"
            payload = (f"CLD2 alpha40 small file {i}\n".encode("utf-8") * 256)
            this_size = min(per, max(128, FILE_SIZE - total)) if total < FILE_SIZE else per
            fill_file(v1 / group / name, this_size, seed=i, pattern=payload)
            total += this_size
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        for i in range(max(1, count // 10)):
            p = v2 / f"group_{i % 16:02d}" / f"file_{i:05d}.dat"
            if p.exists():
                with p.open("ab") as f:
                    f.write((f"\nUPDATED small-file {i}\n".encode("utf-8") * 64))
        for j in range(max(1, count // 20)):
            idx = count + j
            fill_file(v2 / "added" / f"added_{idx:05d}.dat", per, seed=2000 + j, pattern=(b"ADDED_ALPHA40_SMALL_FILE\n" * 128))
        return v1, v2

    raise ValueError(f"unknown scenario: {scenario}")

def make_deterministic_tar(src, dst):
    if dst.exists():
        dst.unlink()
    with tarfile.open(dst, "w") as tf:
        for p in sorted(src.rglob("*")):
            arc = p.relative_to(src).as_posix()
            info = tf.gettarinfo(str(p), arcname=arc)
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            if p.is_file():
                info.mode = 0o644
                with p.open("rb") as f:
                    tf.addfile(info, f)
            elif p.is_dir():
                info.mode = 0o755
                tf.addfile(info)
    return {"path": str(dst), "bytes": dst.stat().st_size, "sha256": sha256_file(dst)}

class CountingHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def copyfile(self, source, outputfile):
        total = 0
        while True:
            buf = source.read(64 * 1024)
            if not buf:
                break
            outputfile.write(buf)
            total += len(buf)
        key = self.path.split("?", 1)[0]
        self.server.byte_counts[key] = self.server.byte_counts.get(key, 0) + total
        self.server.total_bytes += total
        self.server.requests_seen += 1

class CountingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

def run(cmd, cwd=None, timeout=1800):
    t0 = time.time()
    p = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout
    )
    return {
        "cmd": cmd,
        "returncode": p.returncode,
        "ok": p.returncode == 0,
        "seconds": round(time.time() - t0, 3),
        "stdout_tail": p.stdout[-4000:],
        "stderr_tail": p.stderr[-4000:],
    }

def dir_bytes(path):
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())

def start_server(root):
    server = CountingHTTPServer(
        ("127.0.0.1", 0),
        lambda *args, **kwargs: CountingHandler(*args, directory=str(root), **kwargs)
    )
    server.byte_counts = {}
    server.total_bytes = 0
    server.requests_seen = 0
    port = server.server_address[1]
    th = threading.Thread(target=server.serve_forever, daemon=True)
    th.start()
    time.sleep(0.1)
    return server, th, port

def reset_server_counts(server):
    server.byte_counts = {}
    server.total_bytes = 0
    server.requests_seen = 0

def stop_server(server, th):
    try:
        server.shutdown()
        server.server_close()
    finally:
        th.join(timeout=2)

def run_scenario(scenario):
    sroot = TMP / scenario
    pair_root = sroot / "pair"
    repo = sroot / "server_repo"
    client = sroot / "client_repo"
    checkout = sroot / "checkout_v2"

    if sroot.exists():
        shutil.rmtree(sroot)
    sroot.mkdir(parents=True)

    v1, v2 = write_pair(pair_root, scenario)
    tar_info = make_deterministic_tar(v2, sroot / f"{scenario}_v2.tar")

    init_server = run(["ostree", f"--repo={repo}", "init", "--mode=archive"], timeout=300)
    commit_v1 = run([
        "ostree", f"--repo={repo}", "commit",
        "--branch=cld2/v1",
        "--subject=alpha47-v1",
        f"--tree=dir={v1}"
    ], timeout=1800)
    rev_v1 = run(["ostree", f"--repo={repo}", "rev-parse", "cld2/v1"], timeout=300)

    commit_v2 = run([
        "ostree", f"--repo={repo}", "commit",
        "--branch=cld2/v2",
        "--subject=alpha47-v2",
        f"--tree=dir={v2}"
    ], timeout=1800)
    rev_v2 = run(["ostree", f"--repo={repo}", "rev-parse", "cld2/v2"], timeout=300)

    summary = run(["ostree", f"--repo={repo}", "summary", "--update"], timeout=600)

    init_client = run(["ostree", f"--repo={client}", "init", "--mode=archive"], timeout=300)

    server, th, port = start_server(repo)
    remote_url = f"http://127.0.0.1:{port}"

    remote_add = run([
        "ostree", f"--repo={client}", "remote", "add",
        "--no-gpg-verify",
        "origin",
        remote_url
    ], timeout=300)

    pull_v1 = run(["ostree", f"--repo={client}", "pull", "origin", "cld2/v1"], timeout=1800)

    reset_server_counts(server)

    pull_v2 = run(["ostree", f"--repo={client}", "pull", "origin", "cld2/v2"], timeout=1800)

    update_http_bytes = int(server.total_bytes)
    update_requests = int(server.requests_seen)
    byte_counts = dict(server.byte_counts)

    stop_server(server, th)

    remote_rev_v2 = run(["ostree", f"--repo={client}", "rev-parse", "origin:cld2/v2"], timeout=300)
    checkout_cmd = ["ostree", f"--repo={client}", "checkout", "-U", "origin:cld2/v2", str(checkout)]
    checkout_res = run(checkout_cmd, timeout=1800)

    expected = tree_hashes(v2)
    got = tree_hashes(checkout) if checkout.exists() else {}
    verify = {
        "ok": expected == got,
        "missing": sorted(set(expected) - set(got)),
        "extra": sorted(set(got) - set(expected)),
        "mismatch": sorted(k for k in set(expected) & set(got) if expected[k] != got[k]),
    }

    full_tree_bytes = tree_size(v2)

    result = {
        "scenario": scenario,
        "ok": bool(
            init_server["ok"] and commit_v1["ok"] and commit_v2["ok"] and summary["ok"] and
            init_client["ok"] and remote_add["ok"] and pull_v1["ok"] and pull_v2["ok"] and
            checkout_res["ok"] and verify["ok"]
        ),
        "tool": "ostree",
        "mode": "HTTP pull of cld2/v2 after client already pulled cld2/v1; object-level update; no static-delta generated",
        "file_size_target": FILE_SIZE,
        "small_file_count": SMALL_FILE_COUNT,
        "server_url": remote_url,
        "ostree_http_update_bytes": update_http_bytes,
        "ostree_http_update_requests": update_requests,
        "http_byte_counts": byte_counts,
        "ostree_vs_full_tree_ratio": (update_http_bytes / full_tree_bytes) if full_tree_bytes else None,
        "ostree_vs_full_tar_ratio": (update_http_bytes / tar_info["bytes"]) if tar_info["bytes"] else None,
        "full_v2_tree_bytes": full_tree_bytes,
        "full_v2_tar": tar_info,
        "server_repo_bytes": dir_bytes(repo) if repo.exists() else None,
        "client_repo_bytes_after_v2": dir_bytes(client) if client.exists() else None,
        "verify": verify,
        "commands": {
            "init_server": init_server,
            "commit_v1": commit_v1,
            "rev_v1": rev_v1,
            "commit_v2": commit_v2,
            "rev_v2": rev_v2,
            "summary": summary,
            "init_client": init_client,
            "remote_add": remote_add,
            "pull_v1": pull_v1,
            "pull_v2": pull_v2,
            "remote_rev_v2": remote_rev_v2,
            "checkout": checkout_res,
        },
        "claim_boundary_note": "OSTree object-level HTTP pull baseline; not identical to CLD2 warm object-store/chunk planner model.",
    }

    scen_out = OUT / scenario
    scen_out.mkdir(parents=True, exist_ok=True)
    (scen_out / "ostree_scenario_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result

def write_outputs(results):
    summary_csv = OUT / "ostree_baseline_summary.csv"
    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "scenario", "ok", "ostree_http_update_bytes", "full_v2_tree_bytes", "full_v2_tar_bytes",
            "ostree_vs_full_tree_ratio", "ostree_vs_full_tar_ratio",
            "ostree_http_update_requests", "server_repo_bytes", "client_repo_bytes_after_v2"
        ])
        w.writeheader()
        for r in results:
            w.writerow({
                "scenario": r["scenario"],
                "ok": r["ok"],
                "ostree_http_update_bytes": r["ostree_http_update_bytes"],
                "full_v2_tree_bytes": r["full_v2_tree_bytes"],
                "full_v2_tar_bytes": r["full_v2_tar"]["bytes"],
                "ostree_vs_full_tree_ratio": r["ostree_vs_full_tree_ratio"],
                "ostree_vs_full_tar_ratio": r["ostree_vs_full_tar_ratio"],
                "ostree_http_update_requests": r["ostree_http_update_requests"],
                "server_repo_bytes": r["server_repo_bytes"],
                "client_repo_bytes_after_v2": r["client_repo_bytes_after_v2"],
            })

    all_json = {
        "schema": "CLD2/alpha47_ostree_baseline",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool_status": {
            "ostree": "available and benchmarked",
        },
        "benchmark_kind": "alpha47 test milestone, not CLD2 software release",
        "scenarios": results,
        "claim_boundary": [
            "OSTree measured as HTTP pull of v2 after client pulled v1.",
            "No OSTree static-delta generated in this first baseline.",
            "This is object-level repository reuse; not identical to CLD2 warm object-store/chunk planner model.",
            "Do not claim CLD2 always beats OSTree; compare per workload."
        ],
    }
    (OUT / "ostree_baseline_result.json").write_text(json.dumps(all_json, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rows = []
    for r in results:
        rows.append(
            f"| {r['scenario']} | {r['ok']} | {r['ostree_http_update_bytes']} | "
            f"{r['full_v2_tree_bytes']} | {r['full_v2_tar']['bytes']} | "
            f"{r['ostree_vs_full_tree_ratio']} | {r['ostree_vs_full_tar_ratio']} | "
            f"{r['ostree_http_update_requests']} |"
        )

    md = f"""# CLD2 alpha47 ? OSTree baseline

## Verdict

- `ostree`: available and benchmarked.
- Mode: HTTP pull of `cld2/v2` after client already pulled `cld2/v1`.
- Static deltas: not generated in this first baseline.
- Alpha47 is a benchmark/test milestone, not a new CLD2 software release.

## Summary

| Scenario | OK | OSTree HTTP update bytes | full v2 tree bytes | full v2 tar bytes | OSTree/full tree | OSTree/full tar | HTTP requests |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

## Claim boundary

This benchmark measures HTTP response body bytes served during an OSTree pull of v2 after v1 exists locally.
It is relevant because OSTree is a content-addressed update repository, but it is still not identical to CLD2's warm object-store/chunk planner model.
"""
    (OUT / "BASELINE_REPORT.md").write_text(md, encoding="utf-8")
    (OUT / "index.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>CLD2 alpha47 OSTree baseline</title>"
        "<pre>" + md.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</pre>",
        encoding="utf-8"
    )

def main():
    preflight = run(["bash", "-lc", "command -v ostree && ostree --version"], timeout=60)
    (OUT / "preflight_after_install.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not preflight["ok"]:
        raise SystemExit("ostree not available inside WSL")

    results = []
    for s in SCENARIOS:
        print(f"=== alpha47 OSTree scenario: {s} ===", flush=True)
        results.append(run_scenario(s))
    write_outputs(results)

if __name__ == "__main__":
    main()
PY

export CLD2_ALPHA47_OUT="$OUT_LINUX"
python3 "$TMP/alpha47_ostree_runner.py" 2>&1 | tee "$OUT_LINUX/alpha47_ostree_runner_raw.log"
