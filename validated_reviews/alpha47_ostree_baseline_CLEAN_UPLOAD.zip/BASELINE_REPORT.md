# CLD2 alpha47 ? OSTree baseline

## Verdict

- `ostree`: available and benchmarked.
- Mode: HTTP pull of `cld2/v2` after client already pulled `cld2/v1`.
- Static deltas: not generated in this first baseline.
- Alpha47 is a benchmark/test milestone, not a new CLD2 software release.

## Summary

| Scenario | OK | OSTree HTTP update bytes | full v2 tree bytes | full v2 tar bytes | OSTree/full tree | OSTree/full tar | HTTP requests |
|---|---:|---:|---:|---:|---:|---:|---:|
| normal | True | 196227 | 67108959 | 67112960 | 0.002924006018332068 | 0.002923831701060421 | 7 |
| high-entropy | True | 67130107 | 67108936 | 67112960 | 1.0003154721451701 | 1.000255494616837 | 6 |
| small-files | True | 34554 | 70290752 | 70440960 | 0.0004915867168414986 | 0.0004905384594417793 | 47 |
| heavy-change | True | 26971645 | 67108902 | 67112960 | 0.4019086022298502 | 0.40188430073714526 | 6 |

## Claim boundary

This benchmark measures HTTP response body bytes served during an OSTree pull of v2 after v1 exists locally.
It is relevant because OSTree is a content-addressed update repository, but it is still not identical to CLD2's warm object-store/chunk planner model.
