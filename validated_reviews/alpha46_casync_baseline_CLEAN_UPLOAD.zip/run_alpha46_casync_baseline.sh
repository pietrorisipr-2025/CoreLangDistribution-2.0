﻿#!/usr/bin/env bash
set -euo pipefail

OUT_LINUX="$1"
TMP="/tmp/cld2_alpha46_casync_baseline_64MiB"

rm -rf "$TMP"
mkdir -p "$TMP"
mkdir -p "$OUT_LINUX"

cat > "$TMP/alpha46_casync_runner.py" <<'PY'
import csv
import hashlib
import http.server
import json
import os
import random
import shutil
import socketserver
import subprocess
import tarfile
import threading
import time
from pathlib import Path

OUT = Path(os.environ["CLD2_ALPHA46_OUT"])
TMP = Path("/tmp/cld2_alpha46_casync_baseline_64MiB/work")
TMP.mkdir(parents=True, exist_ok=True)

FILE_SIZE = 64 * 1024 * 1024
SMALL_FILE_COUNT = 256
SCENARIOS = ["normal", "high-entropy", "small-files", "heavy-change"]

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def tree_hashes(root: Path):
    out = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            out[p.relative_to(root).as_posix()] = sha256_file(p)
    return out

def tree_size(root: Path) -> int:
    return sum(p.stat().st_size for p in root.rglob("*") if p.is_file())

def fill_file(path: Path, size: int, seed: int = 1, pattern: bytes | None = None):
    path.parent.mkdir(parents=True, exist_ok=True)
    remaining = int(size)
    rnd = random.Random(seed)
    with path.open("wb") as f:
        if pattern:
            while remaining > 0:
                chunk = pattern[:min(len(pattern), remaining)]
                f.write(chunk)
                remaining -= len(chunk)
        else:
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(bytes(rnd.getrandbits(8) for _ in range(n)))
                remaining -= n

def write_pair(root: Path, scenario: str):
    v1 = root / "v1"
    v2 = root / "v2"
    if root.exists():
        shutil.rmtree(root)
    v1.mkdir(parents=True)
    v2.mkdir(parents=True)

    if scenario == "normal":
        block = (b"CLD2_ALPHA33_HTTP_RANGE_ETAG_PILOT\n" * 1024)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=block)
        (v1 / "config").mkdir()
        (v1 / "config" / "settings.json").write_text(
            json.dumps({"version": 1, "mode": "old", "features": ["range", "etag"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        blob = bytearray((v2 / "data.bin").read_bytes())
        start = max(0, len(blob) // 2 - 2048)
        patch = b"CLD2_ALPHA33_LOCALIZED_UPDATE" * 128
        blob[start:start + len(patch)] = patch
        (v2 / "data.bin").write_bytes(bytes(blob))
        (v2 / "config" / "settings.json").write_text(
            json.dumps({"version": 2, "mode": "new", "features": ["range", "etag", "resume"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        return v1, v2

    if scenario == "high-entropy":
        fill_file(v1 / "entropy.bin", FILE_SIZE, seed=404)
        fill_file(v2 / "entropy.bin", FILE_SIZE, seed=405)
        (v1 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 1}) + "\n", encoding="utf-8")
        (v2 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 2, "note": "unrelated entropy"}) + "\n", encoding="utf-8")
        return v1, v2

    if scenario == "heavy-change":
        pattern = (b"CLD2_ALPHA40_HEAVY_CHANGE_STRUCTURED_BLOCK\n" * 4096)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=pattern)
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        p = v2 / "data.bin"
        start = FILE_SIZE // 3
        length = max(1, int(FILE_SIZE * 0.40))
        rnd = random.Random(909)
        with p.open("r+b") as f:
            f.seek(start)
            remaining = min(length, FILE_SIZE - start)
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(bytes(rnd.getrandbits(8) for _ in range(n)))
                remaining -= n
        (v2 / "change.log").write_text("heavy-change: middle region rewritten\n", encoding="utf-8")
        return v1, v2

    if scenario == "small-files":
        count = SMALL_FILE_COUNT
        per = max(128, FILE_SIZE // count)
        total = 0
        for i in range(count):
            group = f"group_{i % 16:02d}"
            name = f"file_{i:05d}.dat"
            payload = (f"CLD2 alpha40 small file {i}\n".encode("utf-8") * 256)
            this_size = min(per, max(128, FILE_SIZE - total)) if total < FILE_SIZE else per
            fill_file(v1 / group / name, this_size, seed=i, pattern=payload)
            total += this_size
        shutil.copytree(v1, v2, dirs_exist_ok=True)
        for i in range(max(1, count // 10)):
            p = v2 / f"group_{i % 16:02d}" / f"file_{i:05d}.dat"
            if p.exists():
                with p.open("ab") as f:
                    f.write((f"\nUPDATED small-file {i}\n".encode("utf-8") * 64))
        for j in range(max(1, count // 20)):
            idx = count + j
            fill_file(v2 / "added" / f"added_{idx:05d}.dat", per, seed=2000 + j, pattern=(b"ADDED_ALPHA40_SMALL_FILE\n" * 128))
        return v1, v2

    raise ValueError(f"unknown scenario: {scenario}")

def make_deterministic_tar(src: Path, dst: Path):
    if dst.exists():
        dst.unlink()
    with tarfile.open(dst, "w") as tf:
        for p in sorted(src.rglob("*")):
            arc = p.relative_to(src).as_posix()
            info = tf.gettarinfo(str(p), arcname=arc)
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            if p.is_file():
                info.mode = 0o644
                with p.open("rb") as f:
                    tf.addfile(info, f)
            elif p.is_dir():
                info.mode = 0o755
                tf.addfile(info)
    return {"path": str(dst), "bytes": dst.stat().st_size, "sha256": sha256_file(dst)}

class CountingHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def copyfile(self, source, outputfile):
        total = 0
        while True:
            buf = source.read(64 * 1024)
            if not buf:
                break
            outputfile.write(buf)
            total += len(buf)
        key = self.path.split("?", 1)[0]
        self.server.byte_counts[key] = self.server.byte_counts.get(key, 0) + total
        self.server.total_bytes += total
        self.server.requests_seen += 1

class CountingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

def run(cmd, cwd=None, timeout=1800):
    t0 = time.time()
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    return {
        "cmd": cmd,
        "returncode": p.returncode,
        "ok": p.returncode == 0,
        "seconds": round(time.time() - t0, 3),
        "stdout_tail": p.stdout[-4000:],
        "stderr_tail": p.stderr[-4000:],
    }

def dir_bytes(path: Path) -> int:
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file())

def run_scenario(scenario: str):
    sroot = TMP / scenario
    pair_root = sroot / "pair"
    http_root = sroot / "http"
    download = sroot / "download"
    http_root.mkdir(parents=True, exist_ok=True)
    download.mkdir(parents=True, exist_ok=True)

    v1, v2 = write_pair(pair_root, scenario)
    tar_info = make_deterministic_tar(v2, sroot / f"{scenario}_v2.tar")

    store = http_root / f"{scenario}.castr"
    index = http_root / f"{scenario}.caidx"

    make_cmd = [
        "casync", "make",
        f"--store={store}",
        "--compression=zstd",
        "--digest=sha256",
        "--with=sec-time",
        "--with=read-only",
        str(index),
        str(v2),
    ]
    make_res = run(make_cmd, timeout=1800)

    extracted = download / "extracted_v2"
    if extracted.exists():
        shutil.rmtree(extracted)

    server = CountingHTTPServer(("127.0.0.1", 0), lambda *args, **kwargs: CountingHandler(*args, directory=str(http_root), **kwargs))
    server.byte_counts = {}
    server.total_bytes = 0
    server.requests_seen = 0
    port = server.server_address[1]
    th = threading.Thread(target=server.serve_forever, daemon=True)
    th.start()
    time.sleep(0.1)

    index_url = f"http://127.0.0.1:{port}/{scenario}.caidx"
    store_url = f"http://127.0.0.1:{port}/{scenario}.castr"

    extract_cmd = [
        "casync", "extract",
        f"--seed={v1}",
        f"--store={store_url}",
        index_url,
        str(extracted),
    ]

    if make_res["ok"]:
        extract_res = run(extract_cmd, timeout=1800)
    else:
        extract_res = {"cmd": extract_cmd, "returncode": -1, "ok": False, "seconds": 0, "stdout_tail": "", "stderr_tail": "skipped because make failed"}

    time.sleep(0.2)
    server.shutdown()
    server.server_close()
    th.join(timeout=2)

    expected = tree_hashes(v2)
    got = tree_hashes(extracted) if extracted.exists() else {}
    verify = {
        "ok": expected == got,
        "missing": sorted(set(expected) - set(got)),
        "extra": sorted(set(got) - set(expected)),
        "mismatch": sorted(k for k in set(expected) & set(got) if expected[k] != got[k]),
    }

    http_bytes = int(server.total_bytes)
    full_tree_bytes = tree_size(v2)
    result = {
        "scenario": scenario,
        "ok": bool(make_res["ok"] and extract_res["ok"] and verify["ok"]),
        "tool": "casync",
        "mode": "HTTP caidx/castr extract with local seed directory",
        "file_size_target": FILE_SIZE,
        "small_file_count": SMALL_FILE_COUNT,
        "casync_make": make_res,
        "casync_extract": extract_res,
        "verify": verify,
        "server_url": f"http://127.0.0.1:{port}/",
        "http_stats": {
            "total_bytes": http_bytes,
            "requests_seen": server.requests_seen,
            "byte_counts": server.byte_counts,
        },
        "casync_http_bytes": http_bytes,
        "casync_vs_full_tree_ratio": (http_bytes / full_tree_bytes) if full_tree_bytes else None,
        "casync_vs_full_tar_ratio": (http_bytes / tar_info["bytes"]) if tar_info["bytes"] else None,
        "full_v2_tree_bytes": full_tree_bytes,
        "full_v2_tar": tar_info,
        "index_bytes": index.stat().st_size if index.exists() else None,
        "store_bytes_total": dir_bytes(store) if store.exists() else None,
        "claim_boundary_note": "casync HTTP seed baseline; not identical to CLD2 object-store warm update model.",
    }

    scen_out = OUT / scenario
    scen_out.mkdir(parents=True, exist_ok=True)
    (scen_out / "casync_scenario_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result

def write_outputs(results):
    summary_csv = OUT / "casync_desync_baseline_summary.csv"
    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "scenario", "ok", "casync_http_bytes", "full_v2_tree_bytes", "full_v2_tar_bytes",
            "casync_vs_full_tree_ratio", "casync_vs_full_tar_ratio", "index_bytes", "store_bytes_total"
        ])
        w.writeheader()
        for r in results:
            w.writerow({
                "scenario": r["scenario"],
                "ok": r["ok"],
                "casync_http_bytes": r["casync_http_bytes"],
                "full_v2_tree_bytes": r["full_v2_tree_bytes"],
                "full_v2_tar_bytes": r["full_v2_tar"]["bytes"],
                "casync_vs_full_tree_ratio": r["casync_vs_full_tree_ratio"],
                "casync_vs_full_tar_ratio": r["casync_vs_full_tar_ratio"],
                "index_bytes": r["index_bytes"],
                "store_bytes_total": r["store_bytes_total"],
            })

    all_json = {
        "schema": "CLD2/alpha46_casync_desync_baseline",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool_status": {
            "casync": "available and benchmarked",
            "desync": "not available in preflight; not benchmarked",
            "go": "not available in preflight; desync build not attempted",
        },
        "scenarios": results,
        "claim_boundary": [
            "casync measured as HTTP caidx/castr extract with local seed.",
            "desync not measured.",
            "Do not claim CLD2 beats casync until this result is reviewed against the validated CLD2 matrix.",
            "Workload model is close but not identical to CLD2 MinIO warm update."
        ],
    }
    (OUT / "casync_desync_baseline_result.json").write_text(json.dumps(all_json, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rows = []
    for r in results:
        rows.append(
            f"| {r['scenario']} | {r['ok']} | {r['casync_http_bytes']} | "
            f"{r['full_v2_tree_bytes']} | {r['full_v2_tar']['bytes']} | "
            f"{r['casync_vs_full_tree_ratio']} | {r['casync_vs_full_tar_ratio']} |"
        )

    md = f"""# CLD2 alpha46 — casync/desync baseline

## Verdict

- `casync`: available and benchmarked.
- `desync`: not available in preflight; not benchmarked.
- Mode: HTTP `.caidx` + `.castr` extract with local seed directory.
- Claim boundary: this is a casync baseline, not proof that CLD2 always wins.

## Summary

| Scenario | OK | casync HTTP bytes | full v2 tree bytes | full v2 tar bytes | casync/full tree | casync/full tar |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

## Notes

This benchmark measures response body bytes served by a local HTTP server during `casync extract --seed=...`.
The result should be compared carefully against the already validated CLD2 warm-update matrix.
"""
    (OUT / "BASELINE_REPORT.md").write_text(md, encoding="utf-8")
    (OUT / "index.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>CLD2 alpha46 casync baseline</title>"
        "<pre>" + md.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</pre>",
        encoding="utf-8"
    )

def main():
    preflight = run(["bash", "-lc", "command -v casync && casync --help | head -20"], timeout=60)
    (OUT / "preflight_after_install.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not preflight["ok"]:
        raise SystemExit("casync not available inside WSL")

    results = []
    for s in SCENARIOS:
        print(f"=== alpha46 casync scenario: {s} ===", flush=True)
        results.append(run_scenario(s))
    write_outputs(results)

if __name__ == "__main__":
    main()
PY

export CLD2_ALPHA46_OUT="$OUT_LINUX"
python3 "$TMP/alpha46_casync_runner.py" 2>&1 | tee "$OUT_LINUX/alpha46_casync_runner_raw.log"
