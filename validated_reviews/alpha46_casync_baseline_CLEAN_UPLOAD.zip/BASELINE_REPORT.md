# CLD2 alpha46 — casync/desync baseline

## Verdict

- `casync`: available and benchmarked.
- `desync`: not available in preflight; not benchmarked.
- Mode: HTTP `.caidx` + `.castr` extract with local seed directory.
- Claim boundary: this is a casync baseline, not proof that CLD2 always wins.

## Summary

| Scenario | OK | casync HTTP bytes | full v2 tree bytes | full v2 tar bytes | casync/full tree | casync/full tar |
|---|---:|---:|---:|---:|---:|---:|
| normal | True | 10986 | 67108959 | 67112960 | 0.00016370392513464558 | 0.00016369416577662497 |
| high-entropy | True | 67160433 | 67108936 | 67112960 | 1.000767364274707 | 1.0007073596515488 |
| small-files | True | 55116 | 70290752 | 70440960 | 0.0007841145304577193 | 0.0007824424880069778 |
| heavy-change | True | 26871717 | 67108902 | 67112960 | 0.40041955983723293 | 0.4003953483798062 |

## Notes

This benchmark measures response body bytes served by a local HTTP server during `casync extract --seed=...`.
The result should be compared carefully against the already validated CLD2 warm-update matrix.
