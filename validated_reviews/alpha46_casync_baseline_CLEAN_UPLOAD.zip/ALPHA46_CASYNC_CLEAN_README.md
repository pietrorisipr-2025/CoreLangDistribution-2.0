# CLD2 alpha46 — casync baseline clean package

Questo ZIP è una versione ripulita del partial upload: il file `alpha46_casync_runner_raw.log` aveva un carattere finale anomalo nel nome, ma i risultati del benchmark erano presenti.

## Casync summary

| Scenario | casync HTTP bytes | CLD2 warm bytes alpha45.8 | CLD2/casync | Lettura provvisoria |
|---|---:|---:|---:|---|
| normal | 10986 | 419 | 0.038139 | CLD2 molto più basso, ma benchmark model non identico |
| high-entropy | 67160433 | 67108937 | 0.999233 | quasi pari |
| small-files | 55116 | 2147 | 0.038954 | CLD2 molto più basso, ma benchmark model non identico |
| heavy-change | 26871717 | 26845855 | 0.999038 | quasi pari |

## Claim boundary

- casync misurato come HTTP `.caidx` + `.castr` extract con seed locale.
- desync non misurato.
- confronto con CLD2 da trattare come indicativo, non perfettamente omogeneo.
- Non dichiarare che CLD2 batte sempre casync/desync.
