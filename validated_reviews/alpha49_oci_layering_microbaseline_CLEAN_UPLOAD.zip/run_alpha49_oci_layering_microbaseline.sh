#!/usr/bin/env bash
set -Eeuo pipefail

OUT_LINUX="$1"
TMP="/tmp/cld2_alpha49_oci_layering_microbaseline_64MiB"

rm -rf "$TMP"
mkdir -p "$TMP"
mkdir -p "$OUT_LINUX"

cat > "$TMP/alpha49_oci_layering_runner.py" <<'PY'
import csv
import gzip
import hashlib
import io
import json
import os
import random
import shutil
import tarfile
import time
from pathlib import Path

OUT = Path(os.environ["CLD2_ALPHA49_OUT"])
TMP = Path("/tmp/cld2_alpha49_oci_layering_microbaseline_64MiB/work")
TMP.mkdir(parents=True, exist_ok=True)

FILE_SIZE = 64 * 1024 * 1024
SMALL_FILE_COUNT = 256
SCENARIOS = ["normal", "high-entropy", "small-files", "heavy-change"]

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()

def sha256_file(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def tree_size(root):
    return sum(p.stat().st_size for p in root.rglob("*") if p.is_file())

def tree_hashes(root):
    out = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            out[p.relative_to(root).as_posix()] = sha256_file(p)
    return out

def fill_file(path, size, seed=1, pattern=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    remaining = int(size)
    rnd = random.Random(seed)
    with path.open("wb") as f:
        if pattern:
            while remaining > 0:
                chunk = pattern[:min(len(pattern), remaining)]
                f.write(chunk)
                remaining -= len(chunk)
        else:
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(rnd.randbytes(n))
                remaining -= n

def write_pair(root, scenario):
    v1 = root / "v1"
    v2 = root / "v2"
    if root.exists():
        shutil.rmtree(root)
    v1.mkdir(parents=True)
    v2.mkdir(parents=True)

    if scenario == "normal":
        block = (b"CLD2_ALPHA33_HTTP_RANGE_ETAG_PILOT\n" * 1024)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=block)
        (v1 / "config").mkdir()
        (v1 / "config" / "settings.json").write_text(
            json.dumps({"version": 1, "mode": "old", "features": ["range", "etag"]}, indent=2) + "\n",
            encoding="utf-8"
        )

        shutil.copytree(v1, v2, dirs_exist_ok=True)

        blob = bytearray((v2 / "data.bin").read_bytes())
        start = max(0, len(blob) // 2 - 2048)
        patch = b"CLD2_ALPHA33_LOCALIZED_UPDATE" * 128
        blob[start:start + len(patch)] = patch
        (v2 / "data.bin").write_bytes(bytes(blob))
        (v2 / "config" / "settings.json").write_text(
            json.dumps({"version": 2, "mode": "new", "features": ["range", "etag", "resume"]}, indent=2) + "\n",
            encoding="utf-8"
        )
        return v1, v2

    if scenario == "high-entropy":
        fill_file(v1 / "entropy.bin", FILE_SIZE, seed=404)
        fill_file(v2 / "entropy.bin", FILE_SIZE, seed=405)
        (v1 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 1}) + "\n", encoding="utf-8")
        (v2 / "meta.json").write_text(json.dumps({"scenario": scenario, "version": 2, "note": "unrelated entropy"}) + "\n", encoding="utf-8")
        return v1, v2

    if scenario == "heavy-change":
        pattern = (b"CLD2_ALPHA40_HEAVY_CHANGE_STRUCTURED_BLOCK\n" * 4096)
        fill_file(v1 / "data.bin", FILE_SIZE, pattern=pattern)
        shutil.copytree(v1, v2, dirs_exist_ok=True)

        p = v2 / "data.bin"
        start = FILE_SIZE // 3
        length = max(1, int(FILE_SIZE * 0.40))
        rnd = random.Random(909)
        with p.open("r+b") as f:
            f.seek(start)
            remaining = min(length, FILE_SIZE - start)
            while remaining > 0:
                n = min(1024 * 1024, remaining)
                f.write(rnd.randbytes(n))
                remaining -= n

        (v2 / "change.log").write_text("heavy-change: middle region rewritten\n", encoding="utf-8")
        return v1, v2

    if scenario == "small-files":
        count = SMALL_FILE_COUNT
        per = max(128, FILE_SIZE // count)
        total = 0
        for i in range(count):
            group = f"group_{i % 16:02d}"
            name = f"file_{i:05d}.dat"
            payload = (f"CLD2 alpha40 small file {i}\n".encode("utf-8") * 256)
            this_size = min(per, max(128, FILE_SIZE - total)) if total < FILE_SIZE else per
            fill_file(v1 / group / name, this_size, seed=i, pattern=payload)
            total += this_size

        shutil.copytree(v1, v2, dirs_exist_ok=True)

        for i in range(max(1, count // 10)):
            p = v2 / f"group_{i % 16:02d}" / f"file_{i:05d}.dat"
            if p.exists():
                with p.open("ab") as f:
                    f.write((f"\nUPDATED small-file {i}\n".encode("utf-8") * 64))

        for j in range(max(1, count // 20)):
            idx = count + j
            fill_file(v2 / "added" / f"added_{idx:05d}.dat", per, seed=2000 + j, pattern=(b"ADDED_ALPHA40_SMALL_FILE\n" * 128))

        return v1, v2

    raise ValueError(f"unknown scenario: {scenario}")

def add_file_to_tar(tf, real_path, arcname):
    info = tf.gettarinfo(str(real_path), arcname=arcname)
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mode = 0o644
    with real_path.open("rb") as f:
        tf.addfile(info, f)

def deterministic_tar_gz_for_paths(root, rel_paths):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as tf:
        for rel in sorted(rel_paths):
            p = root / rel
            if p.is_file():
                add_file_to_tar(tf, p, rel)
    raw_bytes = raw.getvalue()

    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode="wb", compresslevel=6, mtime=0) as gz:
        gz.write(raw_bytes)

    payload = out.getvalue()
    return {
        "bytes": len(payload),
        "sha256": sha256_bytes(payload),
        "uncompressed_tar_bytes": len(raw_bytes),
    }

def deterministic_tar_plain_for_tree(src, dst):
    if dst.exists():
        dst.unlink()
    with tarfile.open(dst, "w") as tf:
        for p in sorted(src.rglob("*")):
            arc = p.relative_to(src).as_posix()
            info = tf.gettarinfo(str(p), arcname=arc)
            info.mtime = 0
            info.uid = 0
            info.gid = 0
            info.uname = ""
            info.gname = ""
            if p.is_file():
                info.mode = 0o644
                with p.open("rb") as f:
                    tf.addfile(info, f)
            elif p.is_dir():
                info.mode = 0o755
                tf.addfile(info)
    return {
        "path": str(dst),
        "bytes": dst.stat().st_size,
        "sha256": sha256_file(dst),
    }

def list_files(root):
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())

def single_layer_model(v1, v2):
    files_v1 = list_files(v1)
    files_v2 = list_files(v2)

    layer_v1 = deterministic_tar_gz_for_paths(v1, files_v1)
    layer_v2 = deterministic_tar_gz_for_paths(v2, files_v2)

    # OCI config/manifest overhead is approximate and small.
    manifest_overhead = len(json.dumps({
        "schemaVersion": 2,
        "mediaType": "application/vnd.oci.image.manifest.v1+json",
        "config": {"mediaType": "application/vnd.oci.image.config.v1+json", "digest": "sha256:" + "0"*64, "size": 512},
        "layers": [{"mediaType": "application/vnd.oci.image.layer.v1.tar+gzip", "digest": "sha256:" + layer_v2["sha256"], "size": layer_v2["bytes"]}],
    }).encode("utf-8")) + 512

    if layer_v1["sha256"] == layer_v2["sha256"]:
        new_bytes = 0
        new_layers = 0
    else:
        new_bytes = layer_v2["bytes"] + manifest_overhead
        new_layers = 1

    return {
        "model": "oci_single_release_layer",
        "description": "one compressed tar.gz layer for the whole release; any changed file invalidates the layer",
        "v1_layer_bytes": layer_v1["bytes"],
        "v2_layer_bytes": layer_v2["bytes"],
        "new_layer_bytes": new_bytes,
        "new_layers": new_layers,
        "manifest_config_overhead_estimate": manifest_overhead,
    }

def per_file_layer_model(v1, v2):
    files_v1 = list_files(v1)
    files_v2 = list_files(v2)

    v1_layers_by_digest = {}
    for rel in files_v1:
        layer = deterministic_tar_gz_for_paths(v1, [rel])
        v1_layers_by_digest[layer["sha256"]] = layer

    new_bytes = 0
    new_layers = 0
    reused_layers = 0
    changed_or_added = []

    v2_layers = []
    for rel in files_v2:
        layer = deterministic_tar_gz_for_paths(v2, [rel])
        v2_layers.append((rel, layer))
        if layer["sha256"] in v1_layers_by_digest:
            reused_layers += 1
        else:
            new_layers += 1
            new_bytes += layer["bytes"]
            changed_or_added.append(rel)

    manifest_overhead = len(json.dumps({
        "schemaVersion": 2,
        "mediaType": "application/vnd.oci.image.manifest.v1+json",
        "config": {"mediaType": "application/vnd.oci.image.config.v1+json", "digest": "sha256:" + "0"*64, "size": 512},
        "layers": [
            {"mediaType": "application/vnd.oci.image.layer.v1.tar+gzip", "digest": "sha256:" + layer["sha256"], "size": layer["bytes"]}
            for _, layer in v2_layers
        ],
    }).encode("utf-8")) + 512

    if new_layers > 0:
        new_bytes += manifest_overhead

    return {
        "model": "oci_per_file_layer",
        "description": "one compressed tar.gz layer per file; unchanged file layers are reused, changed large files still transfer whole file layer",
        "v1_layers": len(files_v1),
        "v2_layers": len(files_v2),
        "reused_layers": reused_layers,
        "new_layers": new_layers,
        "new_layer_bytes": new_bytes,
        "changed_or_added_sample": changed_or_added[:30],
        "changed_or_added_total": len(changed_or_added),
        "manifest_config_overhead_estimate": manifest_overhead,
    }

def run_scenario(scenario):
    sroot = TMP / scenario
    pair_root = sroot / "pair"

    if sroot.exists():
        shutil.rmtree(sroot)
    sroot.mkdir(parents=True)

    v1, v2 = write_pair(pair_root, scenario)
    tar_info = deterministic_tar_plain_for_tree(v2, sroot / f"{scenario}_v2.tar")

    full_tree_bytes = tree_size(v2)
    expected_hashes = tree_hashes(v2)

    single = single_layer_model(v1, v2)
    per_file = per_file_layer_model(v1, v2)

    result = {
        "scenario": scenario,
        "ok": True,
        "tool": "python_oci_layering_model",
        "mode": "simulated OCI layer reuse; no Docker daemon; gzip-compressed deterministic tar layers",
        "file_size_target": FILE_SIZE,
        "small_file_count": SMALL_FILE_COUNT,
        "full_v2_tree_bytes": full_tree_bytes,
        "full_v2_tar": tar_info,
        "v2_file_count": len(expected_hashes),
        "models": {
            "oci_single_release_layer": single,
            "oci_per_file_layer": per_file,
        },
        "metrics": {
            "single_layer_new_bytes": single["new_layer_bytes"],
            "single_layer_vs_full_tree_ratio": (single["new_layer_bytes"] / full_tree_bytes) if full_tree_bytes else None,
            "single_layer_vs_full_tar_ratio": (single["new_layer_bytes"] / tar_info["bytes"]) if tar_info["bytes"] else None,
            "per_file_new_bytes": per_file["new_layer_bytes"],
            "per_file_vs_full_tree_ratio": (per_file["new_layer_bytes"] / full_tree_bytes) if full_tree_bytes else None,
            "per_file_vs_full_tar_ratio": (per_file["new_layer_bytes"] / tar_info["bytes"]) if tar_info["bytes"] else None,
        },
        "claim_boundary_note": "This is an OCI/Docker layering model benchmark, not a real Docker pull and not an exact CLD2 equivalent.",
    }

    scen_out = OUT / scenario
    scen_out.mkdir(parents=True, exist_ok=True)
    (scen_out / "oci_layering_scenario_result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result

def write_outputs(results):
    csv_path = OUT / "oci_layering_microbaseline_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=[
            "scenario",
            "ok",
            "single_layer_new_bytes",
            "per_file_new_bytes",
            "full_v2_tree_bytes",
            "full_v2_tar_bytes",
            "single_layer_vs_full_tree_ratio",
            "per_file_vs_full_tree_ratio",
            "single_new_layers",
            "per_file_new_layers",
            "per_file_reused_layers",
            "v2_file_count"
        ])
        w.writeheader()
        for r in results:
            single = r["models"]["oci_single_release_layer"]
            per_file = r["models"]["oci_per_file_layer"]
            m = r["metrics"]
            w.writerow({
                "scenario": r["scenario"],
                "ok": r["ok"],
                "single_layer_new_bytes": m["single_layer_new_bytes"],
                "per_file_new_bytes": m["per_file_new_bytes"],
                "full_v2_tree_bytes": r["full_v2_tree_bytes"],
                "full_v2_tar_bytes": r["full_v2_tar"]["bytes"],
                "single_layer_vs_full_tree_ratio": m["single_layer_vs_full_tree_ratio"],
                "per_file_vs_full_tree_ratio": m["per_file_vs_full_tree_ratio"],
                "single_new_layers": single["new_layers"],
                "per_file_new_layers": per_file["new_layers"],
                "per_file_reused_layers": per_file["reused_layers"],
                "v2_file_count": r["v2_file_count"],
            })

    all_json = {
        "schema": "CLD2/alpha49_oci_layering_microbaseline",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "benchmark_kind": "alpha49 test/positioning milestone, not CLD2 software release",
        "tool_status": {
            "docker": "not required",
            "oci_layering_model": "benchmarked with Python deterministic tar.gz layers",
        },
        "metric": "new compressed layer bytes required by v2 when v1 layers already exist locally",
        "scenarios": results,
        "claim_boundary": [
            "This is not a real Docker daemon pull.",
            "This is a deterministic OCI/Docker layering model.",
            "Single-release-layer approximates naive Docker COPY of a whole release.",
            "Per-file-layer approximates an engineered image with one layer per file; this is useful for analysis but not typical for very large Dockerfiles.",
            "Layering is not content-defined chunking; changed large files generally require transferring the whole changed layer."
        ],
    }
    (OUT / "oci_layering_microbaseline_result.json").write_text(json.dumps(all_json, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rows = []
    for r in results:
        single = r["models"]["oci_single_release_layer"]
        per_file = r["models"]["oci_per_file_layer"]
        m = r["metrics"]
        rows.append(
            f"| {r['scenario']} | {r['ok']} | {m['single_layer_new_bytes']} | "
            f"{m['per_file_new_bytes']} | {r['full_v2_tree_bytes']} | {r['full_v2_tar']['bytes']} | "
            f"{single['new_layers']} | {per_file['new_layers']} | {per_file['reused_layers']} |"
        )

    md = f"""# CLD2 alpha49 ? OCI/Docker layering micro-baseline

## Verdict

- Docker daemon: not used.
- OCI layering model: benchmarked with deterministic tar.gz layers.
- Alpha49 is a benchmark/positioning milestone, not a CLD2 software release.

## Models

1. `oci_single_release_layer`: one compressed layer for the entire release. Any changed file invalidates the whole layer.
2. `oci_per_file_layer`: one compressed layer per file. Unchanged files are reused, but changed large files still transfer the whole changed file layer.

## Summary

| Scenario | OK | single-layer new bytes | per-file new bytes | full v2 tree bytes | full v2 tar bytes | single new layers | per-file new layers | per-file reused layers |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(rows)}

## Claim boundary

This is not a real Docker pull.
It is a practical model of Docker/OCI layer reuse.
It is useful for positioning but not perfectly equivalent to CLD2's warm chunk/object planner.
"""
    (OUT / "BASELINE_REPORT.md").write_text(md, encoding="utf-8")
    (OUT / "index.html").write_text(
        "<!doctype html><meta charset='utf-8'><title>CLD2 alpha49 OCI layering micro-baseline</title>"
        "<pre>" + md.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</pre>",
        encoding="utf-8"
    )

def main():
    preflight = {
        "python": os.sys.version,
        "note": "No Docker daemon required; deterministic tar.gz OCI layer model.",
    }
    (OUT / "preflight.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    results = []
    for s in SCENARIOS:
        print(f"=== alpha49 OCI layering scenario: {s} ===", flush=True)
        results.append(run_scenario(s))
    write_outputs(results)

if __name__ == "__main__":
    main()
PY

export CLD2_ALPHA49_OUT="$OUT_LINUX"
python3 "$TMP/alpha49_oci_layering_runner.py" 2>&1 | tee "$OUT_LINUX/alpha49_oci_layering_runner_raw.log"
