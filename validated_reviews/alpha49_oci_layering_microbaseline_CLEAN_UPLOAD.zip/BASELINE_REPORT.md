# CLD2 alpha49 ? OCI/Docker layering micro-baseline

## Verdict

- Docker daemon: not used.
- OCI layering model: benchmarked with deterministic tar.gz layers.
- Alpha49 is a benchmark/positioning milestone, not a CLD2 software release.

## Models

1. `oci_single_release_layer`: one compressed layer for the entire release. Any changed file invalidates the whole layer.
2. `oci_per_file_layer`: one compressed layer per file. Unchanged files are reused, but changed large files still transfer the whole changed file layer.

## Summary

| Scenario | OK | single-layer new bytes | per-file new bytes | full v2 tree bytes | full v2 tar bytes | single new layers | per-file new layers | per-file reused layers |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| normal | True | 196511 | 196733 | 67108959 | 67112960 | 1 | 2 | 0 |
| high-entropy | True | 67130606 | 67130785 | 67108936 | 67112960 | 1 | 2 | 0 |
| small-files | True | 188165 | 73044 | 70290752 | 70440960 | 1 | 37 | 231 |
| heavy-change | True | 26971886 | 26972139 | 67108902 | 67112960 | 1 | 2 | 0 |

## Claim boundary

This is not a real Docker pull.
It is a practical model of Docker/OCI layer reuse.
It is useful for positioning but not perfectly equivalent to CLD2's warm chunk/object planner.
