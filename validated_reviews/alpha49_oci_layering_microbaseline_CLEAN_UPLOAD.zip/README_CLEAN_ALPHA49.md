# CLD2 alpha49 — OCI/Docker layering micro-baseline CLEAN

## Status

Alpha49 is a benchmark/positioning milestone, not a new CLD2 software release.

This clean package fixes the raw-log filename that contained a stray private-use/CR-like character.

## Benchmark meaning

This is **not** a real Docker daemon pull.

It is a deterministic OCI/Docker layering model:

1. `OCI single release layer`: one gzip-compressed tar layer for the whole release.
2. `OCI per-file layer`: one gzip-compressed tar layer per file.

Metric: new compressed layer bytes required for v2 when v1 layers are already available.

## alpha49 summary

| Scenario | OCI single-layer new bytes | OCI per-file new bytes | full v2 tree bytes | single new layers | per-file new layers | per-file reused layers |
|---|---:|---:|---:|---:|---:|---:|
| normal | 196511 | 196733 | 67108959 | 1 | 2 | 0 |
| high-entropy | 67130606 | 67130785 | 67108936 | 1 | 2 | 0 |
| small-files | 188165 | 73044 | 70290752 | 1 | 37 | 231 |
| heavy-change | 26971886 | 26972139 | 67108902 | 1 | 2 | 0 |

## Cross-baseline comparison

| Scenario | CLD2 warm | zsync | casync | OSTree | DVC new remote | OCI single-layer | OCI per-file |
|---|---:|---:|---:|---:|---:|---:|---:|
| normal | 419 | 239827 | 10986 | 196227 | 67109107 | 196511 | 196733 |
| high-entropy | 67108937 | 67342559 | 67160433 | 67130107 | 67109076 | 67130606 | 67130785 |
| small-files | 2147 | 3515724 | 55116 | 34554 | 6874124 | 188165 | 73044 |
| heavy-change | 26845855 | 27078879 | 26871717 | 26971645 | 67109040 | 26971886 | 26972139 |

## Verdict

- In `normal`, the OCI layer model is around ~196 KB, close to zsync/OSTree and far above CLD2's 419 bytes.
- In `high-entropy`, OCI is near full transfer, as expected.
- In `small-files`, the per-file layer model is strong (~73 KB), but still above CLD2 and OSTree.
- In `heavy-change`, OCI transfers about 40% of the payload, broadly comparable to zsync/casync/OSTree and close to CLD2.

## Claim boundary

Do not claim this is a real Docker pull.
Do not claim CLD2 beats Docker/OCI in every possible Dockerfile/layering strategy.
The correct claim remains workload-dependent: CLD2 is strongest when warm chunk/object reuse is high, while hostile/high-entropy or large-change cases converge toward other baselines.
